-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: slave.self-spread.mysql.topnews.com    Database: vntopnews_eventlog
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action_log_20190711`
--

DROP TABLE IF EXISTS `action_log_20190711`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190711` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9397 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190712`
--

DROP TABLE IF EXISTS `action_log_20190712`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190712` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10123 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190713`
--

DROP TABLE IF EXISTS `action_log_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=261507 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190715`
--

DROP TABLE IF EXISTS `action_log_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2256063 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190716`
--

DROP TABLE IF EXISTS `action_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=911799 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190717`
--

DROP TABLE IF EXISTS `action_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=938846 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190718`
--

DROP TABLE IF EXISTS `action_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=864191 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190719`
--

DROP TABLE IF EXISTS `action_log_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=877391 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190720`
--

DROP TABLE IF EXISTS `action_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=888748 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190721`
--

DROP TABLE IF EXISTS `action_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1063811 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190722`
--

DROP TABLE IF EXISTS `action_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1110164 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `action_log_20190723`
--

DROP TABLE IF EXISTS `action_log_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action_log_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(32) NOT NULL COMMENT '行为类型',
  `action_params` text COMMENT '行为参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `action_name` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3619 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190628`
--

DROP TABLE IF EXISTS `event_log_20190628`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190628` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190629`
--

DROP TABLE IF EXISTS `event_log_20190629`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190629` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190630`
--

DROP TABLE IF EXISTS `event_log_20190630`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190630` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190713`
--

DROP TABLE IF EXISTS `event_log_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=111320 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190715`
--

DROP TABLE IF EXISTS `event_log_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=968643 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190716`
--

DROP TABLE IF EXISTS `event_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=353538 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190717`
--

DROP TABLE IF EXISTS `event_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=383491 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190718`
--

DROP TABLE IF EXISTS `event_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=351524 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190719`
--

DROP TABLE IF EXISTS `event_log_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=360434 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190720`
--

DROP TABLE IF EXISTS `event_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=362865 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190721`
--

DROP TABLE IF EXISTS `event_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=436053 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190722`
--

DROP TABLE IF EXISTS `event_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=460102 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log_20190723`
--

DROP TABLE IF EXISTS `event_log_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `action_name` varchar(128) NOT NULL COMMENT '行为类型',
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1467 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190713`
--

DROP TABLE IF EXISTS `event_result_log_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=321317 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190714`
--

DROP TABLE IF EXISTS `event_result_log_20190714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190714` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=475965 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190715`
--

DROP TABLE IF EXISTS `event_result_log_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=440041 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190716`
--

DROP TABLE IF EXISTS `event_result_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=379174 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190717`
--

DROP TABLE IF EXISTS `event_result_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=407987 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190718`
--

DROP TABLE IF EXISTS `event_result_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=368669 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190719`
--

DROP TABLE IF EXISTS `event_result_log_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=377836 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190720`
--

DROP TABLE IF EXISTS `event_result_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=378434 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190721`
--

DROP TABLE IF EXISTS `event_result_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=458196 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190722`
--

DROP TABLE IF EXISTS `event_result_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=492613 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_result_log_20190723`
--

DROP TABLE IF EXISTS `event_result_log_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_result_log_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(64) NOT NULL COMMENT '事件类型',
  `event_params` text COMMENT '事件参数',
  `event_action` varchar(64) NOT NULL COMMENT '动作类型：open, close, jump, and etc.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `event_name` (`event_name`),
  KEY `event_action` (`event_action`)
) ENGINE=InnoDB AUTO_INCREMENT=1563 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190713`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=12285110 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190714`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190714` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=11105932 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190715`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=12232497 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190716`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=11791447 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190717`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=12218625 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190718`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=11778648 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190719`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=10918440 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190720`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=10369570 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190721`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=10891203 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190722`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=11148723 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_show_journey_tbl_20190723`
--

DROP TABLE IF EXISTS `event_show_journey_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_show_journey_tbl_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_name` varchar(64) DEFAULT '',
  `action` varchar(64) DEFAULT '',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts_index` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=32796 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190713`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3786197 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190714`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190714` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3473264 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190715`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3747631 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190716`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3409339 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190717`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3668353 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190718`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3673444 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190719`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3427508 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190720`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3308778 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190721`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3375696 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190722`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3406559 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pull_event_list_journey_20190723`
--

DROP TABLE IF EXISTS `pull_event_list_journey_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pull_event_list_journey_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `content` text COMMENT '事件 json str',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=InnoDB AUTO_INCREMENT=10571 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190711`
--

DROP TABLE IF EXISTS `user_action_log_20190711`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190711` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12781501 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190712`
--

DROP TABLE IF EXISTS `user_action_log_20190712`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190712` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11541001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190713`
--

DROP TABLE IF EXISTS `user_action_log_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10716501 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190714`
--

DROP TABLE IF EXISTS `user_action_log_20190714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190714` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10204501 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190715`
--

DROP TABLE IF EXISTS `user_action_log_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10403501 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190716`
--

DROP TABLE IF EXISTS `user_action_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10645001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190717`
--

DROP TABLE IF EXISTS `user_action_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10708001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190718`
--

DROP TABLE IF EXISTS `user_action_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10756501 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190719`
--

DROP TABLE IF EXISTS `user_action_log_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10262001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190720`
--

DROP TABLE IF EXISTS `user_action_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9463001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190721`
--

DROP TABLE IF EXISTS `user_action_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9853001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log_20190722`
--

DROP TABLE IF EXISTS `user_action_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `action` varchar(30) NOT NULL,
  `para` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9005001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举："red_packet" "master_trainee" "new_user_task"',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举："main_page", "master_trainee_tips_page", "new_user_task_tips_page"',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举："open" "close" "drop" "link_jump"',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=79391558 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190712`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190712`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190712` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=9410736 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190713`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190713` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=8294169 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190714`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190714` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7533309 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190715`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190715` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=8080489 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190716`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190716` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7521360 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190717`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=8078490 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190718`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7509659 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190719`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7071365 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190720`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7102270 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190721`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7176370 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190722`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=7291187 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webview_event_show_journey_tbl_20190723`
--

DROP TABLE IF EXISTS `webview_event_show_journey_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webview_event_show_journey_tbl_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL COMMENT '事件流水表中的事件ID',
  `user_id` int(11) unsigned NOT NULL COMMENT '接收红包的用户',
  `event_enum` varchar(64) DEFAULT '' COMMENT '事件类型枚举：red_packet master_trainee new_user_task',
  `page_enum` varchar(64) DEFAULT '' COMMENT '网页类型枚举：main_page, master_trainee_tips_page, new_user_task_tips_page',
  `action_enum` varchar(64) DEFAULT '' COMMENT '动作类型枚举：open close drop link_jump',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_login` smallint(6) DEFAULT NULL,
  `is_bind_phone` smallint(6) DEFAULT NULL,
  `extra_info` text COMMENT 'json str',
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `event_enum_index` (`event_enum`),
  KEY `action_enum` (`action_enum`),
  KEY `page_enum` (`page_enum`)
) ENGINE=InnoDB AUTO_INCREMENT=22469 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-22 17:09:49
