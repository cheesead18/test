-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: slave.pet.mysql.topnews.com    Database: vntopnews_pet
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `already_merge_unreceive_income`
--

DROP TABLE IF EXISTS `already_merge_unreceive_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `already_merge_unreceive_income` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `beg_record_id` bigint(20) NOT NULL,
  `end_record_id` bigint(20) NOT NULL,
  `merge_pet_income` double(16,5) unsigned NOT NULL COMMENT '[beg_record_id, end_record_id] 加成之和',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk` (`user_id`,`tree_id`,`contribution_enum`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `merge_pet_income` (`merge_pet_income`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=4746708 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contribution_journey`
--

DROP TABLE IF EXISTS `contribution_journey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contribution_journey` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` bigint(20) NOT NULL,
  `sid` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `quantity` double(16,5) unsigned NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0' COMMENT 'xu: 表示对应的event_id; lottery 表示对于的action_enum',
  `contribution_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid_unique` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `sid` (`sid`),
  KEY `contribution_utc` (`contribution_utc`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_201810211107`
--

DROP TABLE IF EXISTS `energy_log_tbl_201810211107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_201810211107` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `real_energy` (`real_energy`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2171613 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190529`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190529`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190529` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=525095 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190530`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190530`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190530` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1233935 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190531`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190531`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190531` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1215538 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190601`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190601`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190601` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1193054 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190602`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190602`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190602` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1203553 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190603`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190603`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190603` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1223853 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190604`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190604`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190604` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1215252 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190605`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190605`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190605` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1222715 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190606`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190606`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190606` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1236881 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190607`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190607`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190607` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1197185 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190608`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190608`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190608` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1211004 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190609`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190609`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190609` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1114585 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190610`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190610`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190610` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1098852 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190611`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190611`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190611` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1218303 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190612`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190612`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190612` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1190555 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190613`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190613`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190613` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1190385 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190614`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190614`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190614` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1177930 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190615`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190615`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190615` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1034762 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190616`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190616`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190616` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1046382 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190617`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190617`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190617` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1070135 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190618`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190618`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190618` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1056541 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190619`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190619`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190619` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1077349 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190620`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190620`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190620` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1428664 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190621`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190621`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190621` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1488569 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190622`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190622`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190622` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1472259 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190623`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190623`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190623` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1448757 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190624`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190624`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190624` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1468648 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190625`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190625`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190625` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1367181 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190626`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190626`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190626` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1476176 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190627`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190627`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190627` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1153102 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190628`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190628`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190628` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1382502 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190629`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190629`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190629` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1359746 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190630`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190630`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190630` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1325328 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190701`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190701`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190701` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1383936 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190702`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190702`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190702` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1370006 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190703`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190703`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190703` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1337035 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190704`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190704`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190704` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1382259 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190705`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190705`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190705` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1368087 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190706`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190706`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190706` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1351993 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190707`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190707`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190707` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1340051 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190708`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190708`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190708` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1302521 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190709`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190709`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190709` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1303378 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190710`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190710`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190710` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1299650 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190711`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190711`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190711` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1225357 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190712`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190712`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190712` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1064184 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190713`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190713` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1026256 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190714`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190714` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=968446 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190715`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190715` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=804042 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190716`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190716` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=927073 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190717`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190717` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=959296 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190718`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190718` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=940284 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190719`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190719` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1085317 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190720`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190720` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=874642 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190721`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190721` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=890557 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190722`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190722` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=995578 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `energy_log_tbl_20190723`
--

DROP TABLE IF EXISTS `energy_log_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `energy_log_tbl_20190723` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tree_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `real_energy` double(16,5) NOT NULL DEFAULT '0.00000',
  `org_score` double(16,5) NOT NULL DEFAULT '0.00000',
  `invalid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(128) NOT NULL COMMENT '流水账号',
  `event_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`),
  KEY `tree_id` (`tree_id`),
  KEY `event_utc` (`event_utc`),
  KEY `invalid` (`invalid`),
  KEY `event_id` (`event_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5396 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pet_tree_tbl`
--

DROP TABLE IF EXISTS `pet_tree_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_tree_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `tree_level` int(10) NOT NULL DEFAULT '0',
  `tree_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126608 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_bonus_log_tbl_20190719`
--

DROP TABLE IF EXISTS `recvd_bonus_log_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_bonus_log_tbl_20190719` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `bonus_id` bigint(20) DEFAULT NULL COMMENT '发放的奖励ID（sent_bonus_log_tbl）',
  `recvd_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_bonus_log_tbl_20190720`
--

DROP TABLE IF EXISTS `recvd_bonus_log_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_bonus_log_tbl_20190720` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `bonus_id` bigint(20) DEFAULT NULL COMMENT '发放的奖励ID（sent_bonus_log_tbl）',
  `recvd_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4378 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_bonus_log_tbl_20190721`
--

DROP TABLE IF EXISTS `recvd_bonus_log_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_bonus_log_tbl_20190721` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `bonus_id` bigint(20) DEFAULT NULL COMMENT '发放的奖励ID（sent_bonus_log_tbl）',
  `recvd_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21082 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_bonus_log_tbl_20190722`
--

DROP TABLE IF EXISTS `recvd_bonus_log_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_bonus_log_tbl_20190722` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `bonus_id` bigint(20) DEFAULT NULL COMMENT '发放的奖励ID（sent_bonus_log_tbl）',
  `recvd_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25145 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_bonus_log_tbl_20190723`
--

DROP TABLE IF EXISTS `recvd_bonus_log_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_bonus_log_tbl_20190723` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `bonus_id` bigint(20) DEFAULT NULL COMMENT '发放的奖励ID（sent_bonus_log_tbl）',
  `recvd_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_energy_log_tbl_20190718`
--

DROP TABLE IF EXISTS `recvd_energy_log_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_energy_log_tbl_20190718` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `energy_id` bigint(20) DEFAULT NULL COMMENT '发放的能量ID（sent_energy_log_tbl）',
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_energy_log_tbl_20190719`
--

DROP TABLE IF EXISTS `recvd_energy_log_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_energy_log_tbl_20190719` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `energy_id` bigint(20) DEFAULT NULL COMMENT '发放的能量ID（sent_energy_log_tbl）',
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1403 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_energy_log_tbl_20190720`
--

DROP TABLE IF EXISTS `recvd_energy_log_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_energy_log_tbl_20190720` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `energy_id` bigint(20) DEFAULT NULL COMMENT '发放的能量ID（sent_energy_log_tbl）',
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13440 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_energy_log_tbl_20190721`
--

DROP TABLE IF EXISTS `recvd_energy_log_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_energy_log_tbl_20190721` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `energy_id` bigint(20) DEFAULT NULL COMMENT '发放的能量ID（sent_energy_log_tbl）',
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48652 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_energy_log_tbl_20190722`
--

DROP TABLE IF EXISTS `recvd_energy_log_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_energy_log_tbl_20190722` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `energy_id` bigint(20) DEFAULT NULL COMMENT '发放的能量ID（sent_energy_log_tbl）',
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47940 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recvd_energy_log_tbl_20190723`
--

DROP TABLE IF EXISTS `recvd_energy_log_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recvd_energy_log_tbl_20190723` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `energy_id` bigint(20) DEFAULT NULL COMMENT '发放的能量ID（sent_energy_log_tbl）',
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=345 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rule_tbl`
--

DROP TABLE IF EXISTS `rule_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL DEFAULT '0',
  `energy_minus_per_day` float(10,2) NOT NULL DEFAULT '0.00',
  `min_energy` float(10,2) NOT NULL DEFAULT '0.00',
  `level_need_energy` double(16,5) NOT NULL DEFAULT '0.00000' COMMENT 'level energy',
  `expected_energy` double(16,5) NOT NULL DEFAULT '0.00000' COMMENT 'total energy',
  `master_trainee_ratio` float(10,2) NOT NULL DEFAULT '0.00',
  `red_packet_ratio` float(10,2) NOT NULL DEFAULT '0.00',
  `beginner_task_ratio` float(10,2) NOT NULL DEFAULT '0.00',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level` (`level`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_bonus_log_tbl_20190718`
--

DROP TABLE IF EXISTS `sent_bonus_log_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_bonus_log_tbl_20190718` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `sent_income` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要加成的金额',
  `added_bonus` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最终加成的金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_bonus_log_tbl_20190719`
--

DROP TABLE IF EXISTS `sent_bonus_log_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_bonus_log_tbl_20190719` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `sent_income` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要加成的金额',
  `added_bonus` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最终加成的金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=597 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_bonus_log_tbl_20190720`
--

DROP TABLE IF EXISTS `sent_bonus_log_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_bonus_log_tbl_20190720` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `sent_income` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要加成的金额',
  `added_bonus` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最终加成的金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10509 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_bonus_log_tbl_20190721`
--

DROP TABLE IF EXISTS `sent_bonus_log_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_bonus_log_tbl_20190721` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `sent_income` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要加成的金额',
  `added_bonus` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最终加成的金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63252 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_bonus_log_tbl_20190722`
--

DROP TABLE IF EXISTS `sent_bonus_log_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_bonus_log_tbl_20190722` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `sent_income` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要加成的金额',
  `added_bonus` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最终加成的金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111226 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_bonus_log_tbl_20190723`
--

DROP TABLE IF EXISTS `sent_bonus_log_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_bonus_log_tbl_20190723` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `sent_income` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要加成的金额',
  `added_bonus` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最终加成的金额',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=749 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_energy_log_tbl_20190718`
--

DROP TABLE IF EXISTS `sent_energy_log_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_energy_log_tbl_20190718` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) NOT NULL,
  `sent_energy` int(10) NOT NULL DEFAULT '0' COMMENT '期望增加的能量',
  `added_energy` int(10) NOT NULL DEFAULT '0' COMMENT '实际增加的能量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_energy_log_tbl_20190719`
--

DROP TABLE IF EXISTS `sent_energy_log_tbl_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_energy_log_tbl_20190719` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) NOT NULL,
  `sent_energy` int(10) NOT NULL DEFAULT '0' COMMENT '期望增加的能量',
  `added_energy` int(10) NOT NULL DEFAULT '0' COMMENT '实际增加的能量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=873 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_energy_log_tbl_20190720`
--

DROP TABLE IF EXISTS `sent_energy_log_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_energy_log_tbl_20190720` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) NOT NULL,
  `sent_energy` int(10) NOT NULL DEFAULT '0' COMMENT '期望增加的能量',
  `added_energy` int(10) NOT NULL DEFAULT '0' COMMENT '实际增加的能量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=172318 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_energy_log_tbl_20190721`
--

DROP TABLE IF EXISTS `sent_energy_log_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_energy_log_tbl_20190721` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) NOT NULL,
  `sent_energy` int(10) NOT NULL DEFAULT '0' COMMENT '期望增加的能量',
  `added_energy` int(10) NOT NULL DEFAULT '0' COMMENT '实际增加的能量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=266754 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_energy_log_tbl_20190722`
--

DROP TABLE IF EXISTS `sent_energy_log_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_energy_log_tbl_20190722` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) NOT NULL,
  `sent_energy` int(10) NOT NULL DEFAULT '0' COMMENT '期望增加的能量',
  `added_energy` int(10) NOT NULL DEFAULT '0' COMMENT '实际增加的能量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=283418 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sent_energy_log_tbl_20190723`
--

DROP TABLE IF EXISTS `sent_energy_log_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sent_energy_log_tbl_20190723` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) NOT NULL,
  `sent_energy` int(10) NOT NULL DEFAULT '0' COMMENT '期望增加的能量',
  `added_energy` int(10) NOT NULL DEFAULT '0' COMMENT '实际增加的能量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1975 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tree_bonus_tbl`
--

DROP TABLE IF EXISTS `tree_bonus_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tree_bonus_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `sent_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `unrecvd_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=186534 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tree_energy_tbl`
--

DROP TABLE IF EXISTS `tree_energy_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tree_energy_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `recvd_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `unused_energy` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111776 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tree_tbl`
--

DROP TABLE IF EXISTS `tree_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tree_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `status` int(11) DEFAULT NULL COMMENT '1:alive 2: dead',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dead_time` bigint(15) DEFAULT NULL COMMENT '死亡时间',
  `last_grow_ts` bigint(15) DEFAULT '0' COMMENT '上一次增加能量的时间',
  `start_decay_ts` bigint(15) DEFAULT '0' COMMENT '能量开始衰减的时间',
  `start_downgrade_ts` bigint(15) DEFAULT '0' COMMENT '等级开始下降的时间',
  `notify_dying_times` int(11) DEFAULT '0' COMMENT '通知数濒临死亡的次数',
  `notify_downgrading_times` int(11) DEFAULT '0' COMMENT '通知树濒临降级的次数',
  `latest_unread_status` varchar(64) DEFAULT '' COMMENT '最近未读的发财树状态，已读则置空',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `dead_time` (`dead_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6682696 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_income_record_journal`
--

DROP TABLE IF EXISTS `user_income_record_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_income_record_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `tree_level` int(11) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `parent_event_id` int(11) NOT NULL DEFAULT '0',
  `parent_sid` varchar(128) NOT NULL,
  `parent_income` double(16,5) unsigned NOT NULL,
  `pet_income` double(16,5) unsigned NOT NULL,
  `pet_sid` varchar(128) DEFAULT NULL COMMENT '后期脚本可以通过user_pet_income_mgr中merge_pet_sid的更新',
  `is_pet_add` int(11) NOT NULL DEFAULT '0' COMMENT '是否已经加成',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `is_pet_add` (`is_pet_add`),
  KEY `parent_sid` (`parent_sid`),
  KEY `pet_sid` (`pet_sid`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=16188619 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_income_record_journal_v2`
--

DROP TABLE IF EXISTS `user_income_record_journal_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_income_record_journal_v2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `tree_level` int(11) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `parent_event_id` int(11) NOT NULL DEFAULT '0',
  `parent_sid` varchar(128) NOT NULL,
  `parent_income` double(16,5) unsigned NOT NULL,
  `pet_income` double(16,5) unsigned NOT NULL,
  `pet_sid` varchar(128) DEFAULT NULL COMMENT '后期脚本可以通过user_pet_income_mgr中merge_pet_sid的更新',
  `is_pet_add` int(11) NOT NULL DEFAULT '0' COMMENT '是否已经加成',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `is_pet_add` (`is_pet_add`),
  KEY `parent_sid` (`parent_sid`),
  KEY `pet_sid` (`pet_sid`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=365487343 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_pet_income_mgr`
--

DROP TABLE IF EXISTS `user_pet_income_mgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_pet_income_mgr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `beg_record_id` bigint(20) NOT NULL,
  `end_record_id` bigint(20) NOT NULL,
  `merge_pet_income` double(16,5) unsigned NOT NULL COMMENT '[beg_record_id, end_record_id] 加成之和',
  `merge_pet_sid` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `beg_record_id` (`beg_record_id`),
  KEY `end_record_id` (`end_record_id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=2385883 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_receive_pet_income_failed_journal`
--

DROP TABLE IF EXISTS `user_receive_pet_income_failed_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_receive_pet_income_failed_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `beg_record_id` bigint(20) NOT NULL,
  `end_record_id` bigint(20) NOT NULL,
  `merge_pet_income` double(16,5) unsigned NOT NULL COMMENT '[beg_record_id, end_record_id] 加成之和',
  `process_status` int(11) DEFAULT '0' COMMENT '0: 为处理， 1： 已经通过脚本重新领取成功',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk` (`user_id`,`tree_id`,`contribution_enum`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `beg_record_id` (`beg_record_id`),
  KEY `end_record_id` (`end_record_id`),
  KEY `merge_pet_income` (`merge_pet_income`),
  KEY `process_status` (`process_status`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=28020 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_receive_pet_income_journal`
--

DROP TABLE IF EXISTS `user_receive_pet_income_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_receive_pet_income_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `beg_record_id` bigint(20) NOT NULL,
  `end_record_id` bigint(20) NOT NULL,
  `merge_pet_income` double(16,5) unsigned NOT NULL COMMENT '[beg_record_id, end_record_id] 加成之和',
  `merge_pet_sid` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `beg_record_id` (`beg_record_id`),
  KEY `end_record_id` (`end_record_id`),
  KEY `merge_pet_income` (`merge_pet_income`),
  KEY `merge_pet_sid` (`merge_pet_sid`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=83257787 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_super_tree_tbl`
--

DROP TABLE IF EXISTS `user_super_tree_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_super_tree_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` int(11) NOT NULL,
  `expired_time` timestamp NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`tree_id`),
  KEY `tree_id` (`tree_id`),
  KEY `created_time` (`created_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1415508 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_tree_journal_tbl`
--

DROP TABLE IF EXISTS `user_tree_journal_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_tree_journal_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` int(11) NOT NULL,
  `tree_level` int(11) NOT NULL DEFAULT '0' COMMENT 'tree的等级',
  `user_level` int(11) NOT NULL DEFAULT '0' COMMENT '用户的等级,如果树的等级要大于用户的等级,就要更新一下这个数据, 看是否能升级树的等级\n',
  `expected_energy` float(10,2) NOT NULL DEFAULT '0.00',
  `total_energy` float(10,2) NOT NULL DEFAULT '0.00',
  `dead_times` int(11) NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `continuous_login_times` int(11) NOT NULL DEFAULT '0',
  `total_revenue` double(16,5) NOT NULL DEFAULT '0.00000' COMMENT '当前发财树的贡献值',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`tree_id`),
  KEY `tree_id` (`tree_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_tree_stack_tbl`
--

DROP TABLE IF EXISTS `user_tree_stack_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_tree_stack_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` int(11) NOT NULL,
  `tree_level` int(11) NOT NULL DEFAULT '0' COMMENT 'tree的等级',
  `user_level` int(11) NOT NULL DEFAULT '0' COMMENT '用户的等级,如果树的等级要大于用户的等级,就要更新一下这个数据, 看是否能升级树的等级\n',
  `expected_energy` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'total expected energy of this level',
  `total_energy` float(10,2) NOT NULL DEFAULT '0.00',
  `dead_times` int(11) NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `continuous_login_times` int(11) NOT NULL DEFAULT '0',
  `total_revenue` double(16,5) NOT NULL DEFAULT '0.00000' COMMENT '当前发财树的贡献值',
  `is_recover` int(11) NOT NULL DEFAULT '0' COMMENT '是否已经恢复 0: 没有，1： 已经恢复',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tree_id` (`tree_id`),
  KEY `is_recover` (`is_recover`),
  KEY `created_time` (`created_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1086499 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_tree_tbl`
--

DROP TABLE IF EXISTS `user_tree_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_tree_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` int(11) NOT NULL,
  `tree_level` int(11) NOT NULL DEFAULT '0' COMMENT 'tree的等级',
  `user_level` int(11) NOT NULL DEFAULT '0' COMMENT '用户的等级,如果树的等级要大于用户的等级,就要更新一下这个数据, 看是否能升级树的等级\n',
  `expected_energy` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'total_energy_of_next_level: total expected energy when reach next level',
  `total_energy` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'curr total energy',
  `dead_times` int(11) NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `continuous_login_times` int(11) NOT NULL DEFAULT '0',
  `total_revenue` double(16,5) NOT NULL DEFAULT '0.00000' COMMENT '当前发财树的贡献值',
  `total_xu` double(16,5) DEFAULT '0.00000' COMMENT '当前发财树收益的金币',
  `total_exp` double(16,5) DEFAULT '0.00000' COMMENT '当前发财树收益的经验',
  `total_lottery` int(11) DEFAULT '0' COMMENT '当前发财树收益的奖券',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `tree_id` (`tree_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4262557 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_unreceive_pet_income_mgr`
--

DROP TABLE IF EXISTS `user_unreceive_pet_income_mgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_unreceive_pet_income_mgr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `tree_id` bigint(20) NOT NULL,
  `contribution_enum` varchar(128) NOT NULL,
  `beg_record_id` bigint(20) DEFAULT NULL,
  `end_record_id` bigint(20) DEFAULT NULL,
  `merge_pet_income` double(16,5) unsigned NOT NULL COMMENT '[beg_record_id, end_record_id] 加成之和',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk` (`user_id`,`tree_id`,`contribution_enum`),
  KEY `tree_id` (`tree_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `beg_record_id` (`beg_record_id`),
  KEY `end_record_id` (`end_record_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=335487085 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-22 17:11:42
