-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: slave.log.mysql.topnews.com    Database: vntopnews_log
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ad_browse_log_merge_0809`
--

DROP TABLE IF EXISTS `ad_browse_log_merge_0809`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_browse_log_merge_0809` (
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) unsigned NOT NULL,
  `ad_id` int(11) unsigned NOT NULL,
  `read_src` smallint(6) DEFAULT '0',
  `duration` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_crash_android`
--

DROP TABLE IF EXISTS `app_crash_android`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_crash_android` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL COMMENT 'user_id',
  `client` varchar(128) DEFAULT NULL,
  `app_ver_code` int(10) unsigned DEFAULT '0',
  `app_ver` varchar(128) DEFAULT NULL,
  `manufacturer` varchar(128) DEFAULT NULL,
  `model` varchar(128) DEFAULT NULL,
  `language` varchar(128) DEFAULT NULL,
  `country` varchar(128) DEFAULT NULL,
  `os_ver_code` int(10) unsigned DEFAULT '0',
  `os_ver` varchar(128) DEFAULT NULL,
  `network` int(11) DEFAULT '0',
  `os_rooted` smallint(6) DEFAULT '0',
  `process` varchar(128) DEFAULT NULL,
  `stack_trace` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10664134 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_name_tbl`
--

DROP TABLE IF EXISTS `app_name_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_name_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appname` varchar(128) NOT NULL,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `priority` int(11) DEFAULT '0' COMMENT '优先级',
  PRIMARY KEY (`id`),
  UNIQUE KEY `appname` (`appname`)
) ENGINE=MyISAM AUTO_INCREMENT=824 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_name_tbl_old`
--

DROP TABLE IF EXISTS `app_name_tbl_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_name_tbl_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appname` varchar(128) NOT NULL,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `create_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `appname` (`appname`)
) ENGINE=MyISAM AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180914`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180914`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180914` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1267 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180915`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180915`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180915` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180916`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180916`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180916` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180917`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180917`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180917` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180918`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180918`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180918` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180919`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180919`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180919` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20180920`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20180920`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20180920` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20190716`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20190716` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=960 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20190717`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20190717` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=876 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20190718`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20190718` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1654 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20190720`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20190720` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1674 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20190721`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20190721` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=890 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `author_recommend_history_log_20190722`
--

DROP TABLE IF EXISTS `author_recommend_history_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `author_recommend_history_log_20190722` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `alg_id` int(11) NOT NULL,
  `rcmd_utc` int(11) NOT NULL,
  `detail` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `alg_id` (`alg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=900 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `category_alias_tbl`
--

DROP TABLE IF EXISTS `category_alias_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_alias_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL COMMENT '别名: 一个别名可以属于多个类',
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2916 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `category_tag_relation_tbl`
--

DROP TABLE IF EXISTS `category_tag_relation_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_tag_relation_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id` (`category_id`,`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `category_tbl`
--

DROP TABLE IF EXISTS `category_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `priority` int(11) NOT NULL,
  `det` varchar(64) DEFAULT NULL COMMENT '描述',
  `visible` tinyint(4) DEFAULT '0',
  `version_id` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `priority` (`priority`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `category_user_stat_tbl`
--

DROP TABLE IF EXISTS `category_user_stat_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_user_stat_tbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `utc_begin_ts` timestamp NOT NULL,
  `utc_end_ts` timestamp NOT NULL,
  `category_id` int(11) DEFAULT NULL COMMENT '文章对应的category',
  `cnt` int(11) NOT NULL,
  `user_num` int(11) NOT NULL,
  `avg_num` float(20,3) NOT NULL COMMENT 'cnt/user_num',
  `cat_id` int(11) NOT NULL COMMENT '用户拉去category位置',
  `created_local_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `utc_begin_ts` (`utc_begin_ts`),
  KEY `utc_end_ts` (`utc_end_ts`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content_category_factors`
--

DROP TABLE IF EXISTS `content_category_factors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_category_factors` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned NOT NULL,
  `pub_utc` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `word_cnt` int(11) NOT NULL DEFAULT '0' COMMENT '文章字数',
  `cat_id` int(11) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `cat_id_list` varchar(128) NOT NULL DEFAULT '' COMMENT '所属的大类列表',
  `pub_source_list` varchar(1024) NOT NULL DEFAULT '' COMMENT '来源列表',
  `is_time_sensitive` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否为时效性敏感的内容',
  `ref_count` smallint(6) NOT NULL DEFAULT '1' COMMENT '引用数',
  `recommend_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '推荐次数',
  `read_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `comment_cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `similar_content_cnt` smallint(6) NOT NULL DEFAULT '0' COMMENT '相似内容的content_id数量',
  `hot_value` float NOT NULL DEFAULT '0' COMMENT '计算出来的热度值',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `hot_value` (`hot_value`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=521137344 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content_category_tbl`
--

DROP TABLE IF EXISTS `content_category_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_category_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content_id` bigint(20) NOT NULL COMMENT '一篇文章可以属于不同的大类，也可以有不同的别名',
  `category_id` int(11) DEFAULT NULL,
  `category_alias_id` int(11) DEFAULT NULL,
  `auto_cat` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_id` (`content_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16831295 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deeplink_para_tbl`
--

DROP TABLE IF EXISTS `deeplink_para_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deeplink_para_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `deeplink_id` bigint(20) DEFAULT NULL COMMENT 'vntopnews_user.deferred_deeplink id',
  `uid` int(11) unsigned NOT NULL,
  `did` varchar(64) NOT NULL,
  `os_ver` varchar(32) NOT NULL,
  `app_ver` varchar(32) NOT NULL,
  `model` varchar(32) NOT NULL,
  `manufacturer` varchar(32) NOT NULL,
  `unique_id` varchar(64) NOT NULL,
  `advertiser_id` varchar(64) NOT NULL,
  `appsflyer_id` varchar(64) NOT NULL,
  `root` tinyint(4) DEFAULT '0',
  `source` tinyint(4) DEFAULT '0',
  `deep_link` varchar(1024) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `utc` int(11) DEFAULT NULL,
  `flavor` varchar(128) DEFAULT NULL,
  `campaign` varchar(245) DEFAULT NULL,
  `media_source` varchar(245) DEFAULT NULL,
  `af_adset` varchar(245) DEFAULT NULL,
  `af_tranid` varchar(245) DEFAULT NULL,
  `af_ad` varchar(245) DEFAULT NULL,
  `install_time` varchar(245) DEFAULT NULL,
  `af_status` varchar(245) DEFAULT NULL,
  `adgroup` varchar(245) DEFAULT NULL,
  `orig_cost` varchar(245) DEFAULT NULL,
  `iscache` varchar(245) DEFAULT NULL,
  `click_time` varchar(245) DEFAULT NULL,
  `cost_cents_USD` varchar(245) DEFAULT NULL,
  `agency` varchar(245) DEFAULT NULL,
  `adset` varchar(245) DEFAULT NULL,
  `af_sub1` varchar(245) DEFAULT NULL,
  `af_sub2` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deeplink_id` (`deeplink_id`),
  KEY `campaign` (`campaign`),
  KEY `media_source` (`media_source`)
) ENGINE=MyISAM AUTO_INCREMENT=7221650 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deeplink_para_unique_tbl`
--

DROP TABLE IF EXISTS `deeplink_para_unique_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deeplink_para_unique_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `deeplink_id` bigint(20) DEFAULT NULL COMMENT 'vntopnews_user.deferred_deeplink id',
  `uid` int(11) unsigned NOT NULL,
  `did` varchar(64) NOT NULL,
  `os_ver` varchar(32) NOT NULL,
  `app_ver` varchar(32) NOT NULL,
  `model` varchar(32) NOT NULL,
  `manufacturer` varchar(32) NOT NULL,
  `unique_id` varchar(64) NOT NULL,
  `advertiser_id` varchar(64) NOT NULL,
  `appsflyer_id` varchar(64) NOT NULL,
  `root` tinyint(4) DEFAULT '0',
  `source` tinyint(4) DEFAULT '0',
  `deep_link` varchar(1024) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `utc` int(11) DEFAULT NULL,
  `flavor` varchar(128) DEFAULT NULL,
  `campaign` varchar(245) DEFAULT NULL,
  `media_source` varchar(245) DEFAULT NULL,
  `af_adset` varchar(245) DEFAULT NULL,
  `af_tranid` varchar(245) DEFAULT NULL,
  `af_ad` varchar(245) DEFAULT NULL,
  `install_time` varchar(245) DEFAULT NULL,
  `af_status` varchar(245) DEFAULT NULL,
  `adgroup` varchar(245) DEFAULT NULL,
  `orig_cost` varchar(245) DEFAULT NULL,
  `iscache` varchar(245) DEFAULT NULL,
  `click_time` varchar(245) DEFAULT NULL,
  `cost_cents_USD` varchar(245) DEFAULT NULL,
  `agency` varchar(245) DEFAULT NULL,
  `adset` varchar(245) DEFAULT NULL,
  `af_sub1` varchar(245) DEFAULT NULL,
  `af_sub2` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `advertiser_id` (`advertiser_id`),
  KEY `deeplink_id` (`deeplink_id`),
  KEY `campaign` (`campaign`),
  KEY `media_source` (`media_source`)
) ENGINE=MyISAM AUTO_INCREMENT=5359128 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190716`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190716` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32858209 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190717`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190717` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34104105 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190718`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190718` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33558428 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190720`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190720` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31293163 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190721`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190721` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33903079 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190722`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190722` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27409902 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `heartbeat_tbl_20190723`
--

DROP TABLE IF EXISTS `heartbeat_tbl_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heartbeat_tbl_20190723` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '用户UID',
  `device_os` varchar(128) DEFAULT NULL COMMENT '手机系统版本',
  `version` varchar(32) DEFAULT NULL COMMENT '客户端版本号',
  `flavor` varchar(128) DEFAULT NULL COMMENT '客户端APP类型',
  `event_ts` int(10) unsigned NOT NULL COMMENT '接口请求时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_click_uid`
--

DROP TABLE IF EXISTS `push_click_uid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_click_uid` (
  `uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_cliked_user_of_compensate_msg`
--

DROP TABLE IF EXISTS `push_cliked_user_of_compensate_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_cliked_user_of_compensate_msg` (
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190716`
--

DROP TABLE IF EXISTS `push_stat_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190716` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190717`
--

DROP TABLE IF EXISTS `push_stat_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190717` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190718`
--

DROP TABLE IF EXISTS `push_stat_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190718` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190720`
--

DROP TABLE IF EXISTS `push_stat_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190720` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190721`
--

DROP TABLE IF EXISTS `push_stat_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190721` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190722`
--

DROP TABLE IF EXISTS `push_stat_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190722` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_stat_20190723`
--

DROP TABLE IF EXISTS `push_stat_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_stat_20190723` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL,
  `app_opened` smallint(6) NOT NULL DEFAULT '0',
  `msg_id` varchar(64) NOT NULL DEFAULT '',
  `network` tinyint(4) DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pushclick`
--

DROP TABLE IF EXISTS `pushclick`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pushclick` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15378 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `read1`
--

DROP TABLE IF EXISTS `read1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `read1` (
  `alg_id` smallint(6) DEFAULT '-1',
  `count` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `read2`
--

DROP TABLE IF EXISTS `read2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `read2` (
  `alg_id` smallint(6) DEFAULT '-1',
  `count` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recommend1`
--

DROP TABLE IF EXISTS `recommend1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recommend1` (
  `alg_id` smallint(6) DEFAULT '-1',
  `count` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recommend2`
--

DROP TABLE IF EXISTS `recommend2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recommend2` (
  `alg_id` smallint(6) DEFAULT '-1',
  `count` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rt_user_daily_duration_stat`
--

DROP TABLE IF EXISTS `rt_user_daily_duration_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rt_user_daily_duration_stat` (
  `user_id` int(10) unsigned NOT NULL,
  `date_str` varchar(8) NOT NULL,
  `duration` int(11) DEFAULT '0',
  `duration_2` int(11) DEFAULT '0',
  PRIMARY KEY (`user_id`,`date_str`),
  KEY `user_id` (`user_id`),
  KEY `date_str` (`date_str`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_action_log`
--

DROP TABLE IF EXISTS `user_action_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_action_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(256) NOT NULL COMMENT '用户id，可能为 deviceid, uuid, user_id(用户注册id)',
  `action` int(11) NOT NULL COMMENT '用户行为：1: register, 11:list_down, 12:list_up, 13:list, 20:detail, 21:detail_end, 25:detail_recommend, 30:facebook, 31: share_other, 50:refuse, 100:push, 101:push_click, 200:origin',
  `parameter` text COMMENT '对应参数: register: {client_ver}, list_down,list_up: category_id( 0 为推荐频道), list:{category_id(NULL为推荐频道), [文章id,...]}, detail: 文章id, detail_end: {文章id, 阅读时长， 阅读比例}, detail_recommend: 文章id， facebook:文章id, share_other: {文章id, 分享应用名}, refuse: 文章id, push,push_click: 消息id, origin:文章id',
  `action_time` datetime NOT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_applist_state_tbl`
--

DROP TABLE IF EXISTS `user_applist_state_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_applist_state_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'uid',
  `dispatch_count` int(11) NOT NULL DEFAULT '0' COMMENT '下发个数',
  `dispatch_times` int(11) NOT NULL DEFAULT '0' COMMENT '下发次数',
  `report_count` int(11) NOT NULL DEFAULT '0' COMMENT '上报个数',
  `report_times` int(11) NOT NULL DEFAULT '0' COMMENT '上报次数',
  `finish_times` int(11) NOT NULL DEFAULT '0' COMMENT '下发完成计数',
  `create_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=6546059 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_avg_stat_hour_stat`
--

DROP TABLE IF EXISTS `user_avg_stat_hour_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_avg_stat_hour_stat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `utc_begin_ts` timestamp NOT NULL,
  `utc_end_ts` timestamp NOT NULL,
  `auto_refresh_users` int(11) NOT NULL COMMENT '自动刷新的人数',
  `auto_refresh_avg` float(20,3) NOT NULL COMMENT '每人自动刷新的次数',
  `refresh_users` int(11) NOT NULL COMMENT '手动刷新的人数',
  `refresh_avg` float(20,3) NOT NULL COMMENT '每人手动刷新的次数',
  `read_users` int(11) NOT NULL COMMENT '阅读人数',
  `read_avg` float(20,3) NOT NULL COMMENT '人均阅读文章数',
  `cat_id` int(11) NOT NULL COMMENT 'NULL表示不区分cat_id的一小时统计结果, 否则是对应cat_id的统计',
  `created_local_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `utc_begin_ts` (`utc_begin_ts`),
  KEY `utc_end_ts` (`utc_end_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=76648 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190716`
--

DROP TABLE IF EXISTS `user_category_list_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190716` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=199902 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190717`
--

DROP TABLE IF EXISTS `user_category_list_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190717` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=177327 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190718`
--

DROP TABLE IF EXISTS `user_category_list_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190718` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=177325 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190720`
--

DROP TABLE IF EXISTS `user_category_list_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190720` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=153679 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190721`
--

DROP TABLE IF EXISTS `user_category_list_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190721` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=169135 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190722`
--

DROP TABLE IF EXISTS `user_category_list_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190722` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=175497 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_category_list_log_20190723`
--

DROP TABLE IF EXISTS `user_category_list_log_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category_list_log_20190723` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `cat_list` varchar(128) DEFAULT NULL,
  `adjust_type` int(11) DEFAULT '1' COMMENT '1为自动调整，2为用户手动调整',
  `register_cnt` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_daily_duration_stat`
--

DROP TABLE IF EXISTS `user_daily_duration_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_daily_duration_stat` (
  `user_id` int(10) unsigned NOT NULL,
  `date_str` varchar(8) NOT NULL,
  `duration` int(11) DEFAULT '0',
  `duration_2` int(11) DEFAULT '0',
  PRIMARY KEY (`user_id`,`date_str`),
  KEY `user_id` (`user_id`),
  KEY `date_str` (`date_str`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_daily_duration_stat_v2`
--

DROP TABLE IF EXISTS `user_daily_duration_stat_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_daily_duration_stat_v2` (
  `user_id` int(10) unsigned NOT NULL,
  `date_str` varchar(8) NOT NULL,
  `hour` smallint(6) NOT NULL,
  `duration` int(11) DEFAULT '0',
  `duration_2` int(11) DEFAULT '0',
  UNIQUE KEY `user_id` (`user_id`,`date_str`,`hour`),
  KEY `hour` (`hour`),
  KEY `date_str` (`date_str`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_duration`
--

DROP TABLE IF EXISTS `user_duration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_duration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `date` date NOT NULL,
  `new` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=177110 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180531`
--

DROP TABLE IF EXISTS `user_follow_log_20180531`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180531` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=6973 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180601`
--

DROP TABLE IF EXISTS `user_follow_log_20180601`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180601` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=17323 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180602`
--

DROP TABLE IF EXISTS `user_follow_log_20180602`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180602` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18008 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180603`
--

DROP TABLE IF EXISTS `user_follow_log_20180603`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180603` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=26502 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180604`
--

DROP TABLE IF EXISTS `user_follow_log_20180604`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180604` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=22247 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180605`
--

DROP TABLE IF EXISTS `user_follow_log_20180605`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180605` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19509 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180606`
--

DROP TABLE IF EXISTS `user_follow_log_20180606`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180606` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18985 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180607`
--

DROP TABLE IF EXISTS `user_follow_log_20180607`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180607` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=26700 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180608`
--

DROP TABLE IF EXISTS `user_follow_log_20180608`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180608` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=20076 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180609`
--

DROP TABLE IF EXISTS `user_follow_log_20180609`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180609` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18898 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180610`
--

DROP TABLE IF EXISTS `user_follow_log_20180610`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180610` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18171 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180611`
--

DROP TABLE IF EXISTS `user_follow_log_20180611`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180611` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19966 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180612`
--

DROP TABLE IF EXISTS `user_follow_log_20180612`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180612` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19288 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180613`
--

DROP TABLE IF EXISTS `user_follow_log_20180613`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180613` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=29587 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180614`
--

DROP TABLE IF EXISTS `user_follow_log_20180614`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180614` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=24244 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180615`
--

DROP TABLE IF EXISTS `user_follow_log_20180615`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180615` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19824 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180616`
--

DROP TABLE IF EXISTS `user_follow_log_20180616`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180616` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19574 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180617`
--

DROP TABLE IF EXISTS `user_follow_log_20180617`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180617` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18739 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180618`
--

DROP TABLE IF EXISTS `user_follow_log_20180618`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180618` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19413 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180619`
--

DROP TABLE IF EXISTS `user_follow_log_20180619`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180619` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=23872 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180620`
--

DROP TABLE IF EXISTS `user_follow_log_20180620`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180620` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19801 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180621`
--

DROP TABLE IF EXISTS `user_follow_log_20180621`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180621` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18991 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180622`
--

DROP TABLE IF EXISTS `user_follow_log_20180622`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180622` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=20067 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180623`
--

DROP TABLE IF EXISTS `user_follow_log_20180623`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180623` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19000 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180624`
--

DROP TABLE IF EXISTS `user_follow_log_20180624`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180624` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18576 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180625`
--

DROP TABLE IF EXISTS `user_follow_log_20180625`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180625` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18273 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180626`
--

DROP TABLE IF EXISTS `user_follow_log_20180626`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180626` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18732 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180627`
--

DROP TABLE IF EXISTS `user_follow_log_20180627`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180627` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18374 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180628`
--

DROP TABLE IF EXISTS `user_follow_log_20180628`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180628` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=17733 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180629`
--

DROP TABLE IF EXISTS `user_follow_log_20180629`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180629` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=17065 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180630`
--

DROP TABLE IF EXISTS `user_follow_log_20180630`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180630` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=15399 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180701`
--

DROP TABLE IF EXISTS `user_follow_log_20180701`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180701` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=16993 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180702`
--

DROP TABLE IF EXISTS `user_follow_log_20180702`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180702` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18312 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180703`
--

DROP TABLE IF EXISTS `user_follow_log_20180703`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180703` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=15900 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180704`
--

DROP TABLE IF EXISTS `user_follow_log_20180704`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180704` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=16061 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180705`
--

DROP TABLE IF EXISTS `user_follow_log_20180705`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180705` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=16755 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180706`
--

DROP TABLE IF EXISTS `user_follow_log_20180706`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180706` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=16473 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180707`
--

DROP TABLE IF EXISTS `user_follow_log_20180707`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180707` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18015 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180708`
--

DROP TABLE IF EXISTS `user_follow_log_20180708`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180708` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=17624 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180709`
--

DROP TABLE IF EXISTS `user_follow_log_20180709`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180709` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=18335 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180710`
--

DROP TABLE IF EXISTS `user_follow_log_20180710`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180710` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19909 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180711`
--

DROP TABLE IF EXISTS `user_follow_log_20180711`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180711` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19319 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180712`
--

DROP TABLE IF EXISTS `user_follow_log_20180712`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180712` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=20273 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180713`
--

DROP TABLE IF EXISTS `user_follow_log_20180713`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180713` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=19740 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180714`
--

DROP TABLE IF EXISTS `user_follow_log_20180714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180714` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=21428 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180715`
--

DROP TABLE IF EXISTS `user_follow_log_20180715`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180715` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=20713 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180716`
--

DROP TABLE IF EXISTS `user_follow_log_20180716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180716` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=20614 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180717`
--

DROP TABLE IF EXISTS `user_follow_log_20180717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180717` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=21523 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180718`
--

DROP TABLE IF EXISTS `user_follow_log_20180718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180718` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=24625 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180719`
--

DROP TABLE IF EXISTS `user_follow_log_20180719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180719` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=32323 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180720`
--

DROP TABLE IF EXISTS `user_follow_log_20180720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180720` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=30977 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180721`
--

DROP TABLE IF EXISTS `user_follow_log_20180721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180721` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=24995 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180722`
--

DROP TABLE IF EXISTS `user_follow_log_20180722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180722` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=22328 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180723`
--

DROP TABLE IF EXISTS `user_follow_log_20180723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180723` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=22309 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180724`
--

DROP TABLE IF EXISTS `user_follow_log_20180724`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180724` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=22782 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180725`
--

DROP TABLE IF EXISTS `user_follow_log_20180725`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180725` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=22364 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180726`
--

DROP TABLE IF EXISTS `user_follow_log_20180726`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180726` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=25223 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180727`
--

DROP TABLE IF EXISTS `user_follow_log_20180727`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180727` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=26964 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180728`
--

DROP TABLE IF EXISTS `user_follow_log_20180728`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180728` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=25771 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180729`
--

DROP TABLE IF EXISTS `user_follow_log_20180729`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180729` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=34294 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180730`
--

DROP TABLE IF EXISTS `user_follow_log_20180730`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180730` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=31914 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180731`
--

DROP TABLE IF EXISTS `user_follow_log_20180731`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180731` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=25924 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180801`
--

DROP TABLE IF EXISTS `user_follow_log_20180801`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180801` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=28323 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180802`
--

DROP TABLE IF EXISTS `user_follow_log_20180802`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180802` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=33115 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180803`
--

DROP TABLE IF EXISTS `user_follow_log_20180803`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180803` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=34650 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180804`
--

DROP TABLE IF EXISTS `user_follow_log_20180804`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180804` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=34522 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180805`
--

DROP TABLE IF EXISTS `user_follow_log_20180805`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180805` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=35486 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180806`
--

DROP TABLE IF EXISTS `user_follow_log_20180806`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180806` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=34418 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180807`
--

DROP TABLE IF EXISTS `user_follow_log_20180807`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180807` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=33140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180808`
--

DROP TABLE IF EXISTS `user_follow_log_20180808`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180808` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=33797 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180809`
--

DROP TABLE IF EXISTS `user_follow_log_20180809`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180809` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=33549 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180810`
--

DROP TABLE IF EXISTS `user_follow_log_20180810`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180810` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=34302 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180811`
--

DROP TABLE IF EXISTS `user_follow_log_20180811`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180811` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=33747 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180812`
--

DROP TABLE IF EXISTS `user_follow_log_20180812`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180812` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=38360 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180813`
--

DROP TABLE IF EXISTS `user_follow_log_20180813`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180813` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41780 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180814`
--

DROP TABLE IF EXISTS `user_follow_log_20180814`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180814` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44230 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180815`
--

DROP TABLE IF EXISTS `user_follow_log_20180815`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180815` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41572 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180816`
--

DROP TABLE IF EXISTS `user_follow_log_20180816`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180816` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=46361 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180817`
--

DROP TABLE IF EXISTS `user_follow_log_20180817`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180817` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40997 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180818`
--

DROP TABLE IF EXISTS `user_follow_log_20180818`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180818` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=38375 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180819`
--

DROP TABLE IF EXISTS `user_follow_log_20180819`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180819` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40547 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180820`
--

DROP TABLE IF EXISTS `user_follow_log_20180820`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180820` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=37999 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180821`
--

DROP TABLE IF EXISTS `user_follow_log_20180821`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180821` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40620 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180822`
--

DROP TABLE IF EXISTS `user_follow_log_20180822`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180822` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40767 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180823`
--

DROP TABLE IF EXISTS `user_follow_log_20180823`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180823` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=43016 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180824`
--

DROP TABLE IF EXISTS `user_follow_log_20180824`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180824` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=38553 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180825`
--

DROP TABLE IF EXISTS `user_follow_log_20180825`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180825` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=37483 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180826`
--

DROP TABLE IF EXISTS `user_follow_log_20180826`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180826` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40335 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180827`
--

DROP TABLE IF EXISTS `user_follow_log_20180827`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180827` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=43976 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180828`
--

DROP TABLE IF EXISTS `user_follow_log_20180828`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180828` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=49509 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180829`
--

DROP TABLE IF EXISTS `user_follow_log_20180829`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180829` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=54897 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180830`
--

DROP TABLE IF EXISTS `user_follow_log_20180830`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180830` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=56125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180831`
--

DROP TABLE IF EXISTS `user_follow_log_20180831`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180831` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=42823 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180901`
--

DROP TABLE IF EXISTS `user_follow_log_20180901`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180901` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=63935 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180902`
--

DROP TABLE IF EXISTS `user_follow_log_20180902`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180902` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=110059 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180903`
--

DROP TABLE IF EXISTS `user_follow_log_20180903`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180903` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=67902 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180904`
--

DROP TABLE IF EXISTS `user_follow_log_20180904`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180904` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=98639 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180905`
--

DROP TABLE IF EXISTS `user_follow_log_20180905`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180905` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=101631 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180906`
--

DROP TABLE IF EXISTS `user_follow_log_20180906`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180906` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41447 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180907`
--

DROP TABLE IF EXISTS `user_follow_log_20180907`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180907` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41728 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180908`
--

DROP TABLE IF EXISTS `user_follow_log_20180908`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180908` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=46284 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180909`
--

DROP TABLE IF EXISTS `user_follow_log_20180909`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180909` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=48300 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180910`
--

DROP TABLE IF EXISTS `user_follow_log_20180910`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180910` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40444 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180911`
--

DROP TABLE IF EXISTS `user_follow_log_20180911`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180911` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=35931 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180912`
--

DROP TABLE IF EXISTS `user_follow_log_20180912`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180912` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=36461 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180913`
--

DROP TABLE IF EXISTS `user_follow_log_20180913`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180913` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=39465 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180914`
--

DROP TABLE IF EXISTS `user_follow_log_20180914`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180914` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41388 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180915`
--

DROP TABLE IF EXISTS `user_follow_log_20180915`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180915` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=39941 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180916`
--

DROP TABLE IF EXISTS `user_follow_log_20180916`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180916` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44224 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180917`
--

DROP TABLE IF EXISTS `user_follow_log_20180917`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180917` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44324 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180918`
--

DROP TABLE IF EXISTS `user_follow_log_20180918`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180918` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=49249 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180919`
--

DROP TABLE IF EXISTS `user_follow_log_20180919`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180919` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=49903 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180920`
--

DROP TABLE IF EXISTS `user_follow_log_20180920`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180920` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=46136 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180921`
--

DROP TABLE IF EXISTS `user_follow_log_20180921`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180921` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=48908 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180922`
--

DROP TABLE IF EXISTS `user_follow_log_20180922`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180922` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=45960 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180923`
--

DROP TABLE IF EXISTS `user_follow_log_20180923`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180923` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=45170 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180924`
--

DROP TABLE IF EXISTS `user_follow_log_20180924`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180924` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40525 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180925`
--

DROP TABLE IF EXISTS `user_follow_log_20180925`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180925` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=39283 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180926`
--

DROP TABLE IF EXISTS `user_follow_log_20180926`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180926` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=42059 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180927`
--

DROP TABLE IF EXISTS `user_follow_log_20180927`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180927` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41868 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180928`
--

DROP TABLE IF EXISTS `user_follow_log_20180928`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180928` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=40410 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180929`
--

DROP TABLE IF EXISTS `user_follow_log_20180929`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180929` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=39590 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20180930`
--

DROP TABLE IF EXISTS `user_follow_log_20180930`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20180930` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=43353 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181001`
--

DROP TABLE IF EXISTS `user_follow_log_20181001`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181001` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=43345 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181002`
--

DROP TABLE IF EXISTS `user_follow_log_20181002`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181002` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=45629 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181003`
--

DROP TABLE IF EXISTS `user_follow_log_20181003`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181003` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=42920 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181004`
--

DROP TABLE IF EXISTS `user_follow_log_20181004`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181004` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=42421 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181005`
--

DROP TABLE IF EXISTS `user_follow_log_20181005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181005` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44629 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181006`
--

DROP TABLE IF EXISTS `user_follow_log_20181006`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181006` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=42582 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181007`
--

DROP TABLE IF EXISTS `user_follow_log_20181007`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181007` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=43001 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181008`
--

DROP TABLE IF EXISTS `user_follow_log_20181008`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181008` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=41535 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181009`
--

DROP TABLE IF EXISTS `user_follow_log_20181009`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181009` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=42174 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181010`
--

DROP TABLE IF EXISTS `user_follow_log_20181010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181010` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44212 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181011`
--

DROP TABLE IF EXISTS `user_follow_log_20181011`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181011` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44576 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181012`
--

DROP TABLE IF EXISTS `user_follow_log_20181012`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181012` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=44146 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181013`
--

DROP TABLE IF EXISTS `user_follow_log_20181013`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181013` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=49743 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181014`
--

DROP TABLE IF EXISTS `user_follow_log_20181014`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181014` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=50176 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181015`
--

DROP TABLE IF EXISTS `user_follow_log_20181015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181015` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=52656 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181016`
--

DROP TABLE IF EXISTS `user_follow_log_20181016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181016` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=55259 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181017`
--

DROP TABLE IF EXISTS `user_follow_log_20181017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181017` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=57614 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181018`
--

DROP TABLE IF EXISTS `user_follow_log_20181018`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181018` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=60482 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181019`
--

DROP TABLE IF EXISTS `user_follow_log_20181019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181019` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=62234 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181020`
--

DROP TABLE IF EXISTS `user_follow_log_20181020`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181020` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=62038 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181021`
--

DROP TABLE IF EXISTS `user_follow_log_20181021`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181021` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=62188 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181022`
--

DROP TABLE IF EXISTS `user_follow_log_20181022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181022` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=64275 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181023`
--

DROP TABLE IF EXISTS `user_follow_log_20181023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181023` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=64865 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181024`
--

DROP TABLE IF EXISTS `user_follow_log_20181024`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181024` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=77591 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181025`
--

DROP TABLE IF EXISTS `user_follow_log_20181025`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181025` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=75543 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181026`
--

DROP TABLE IF EXISTS `user_follow_log_20181026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181026` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=71155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181027`
--

DROP TABLE IF EXISTS `user_follow_log_20181027`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181027` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=72812 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181028`
--

DROP TABLE IF EXISTS `user_follow_log_20181028`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181028` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=83716 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181029`
--

DROP TABLE IF EXISTS `user_follow_log_20181029`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181029` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=78870 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181030`
--

DROP TABLE IF EXISTS `user_follow_log_20181030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181030` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=79094 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181031`
--

DROP TABLE IF EXISTS `user_follow_log_20181031`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181031` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=85574 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181101`
--

DROP TABLE IF EXISTS `user_follow_log_20181101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181101` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=84005 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181102`
--

DROP TABLE IF EXISTS `user_follow_log_20181102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181102` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=80044 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181103`
--

DROP TABLE IF EXISTS `user_follow_log_20181103`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181103` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=82751 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181104`
--

DROP TABLE IF EXISTS `user_follow_log_20181104`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181104` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=81502 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181105`
--

DROP TABLE IF EXISTS `user_follow_log_20181105`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181105` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=85882 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181106`
--

DROP TABLE IF EXISTS `user_follow_log_20181106`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181106` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=81084 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181107`
--

DROP TABLE IF EXISTS `user_follow_log_20181107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181107` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=78813 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181108`
--

DROP TABLE IF EXISTS `user_follow_log_20181108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181108` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=73265 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181109`
--

DROP TABLE IF EXISTS `user_follow_log_20181109`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181109` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=73898 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181110`
--

DROP TABLE IF EXISTS `user_follow_log_20181110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181110` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=68532 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181111`
--

DROP TABLE IF EXISTS `user_follow_log_20181111`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181111` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=75364 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181112`
--

DROP TABLE IF EXISTS `user_follow_log_20181112`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181112` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=76224 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181113`
--

DROP TABLE IF EXISTS `user_follow_log_20181113`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181113` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=75446 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181114`
--

DROP TABLE IF EXISTS `user_follow_log_20181114`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181114` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=69856 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181115`
--

DROP TABLE IF EXISTS `user_follow_log_20181115`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181115` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=69077 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181116`
--

DROP TABLE IF EXISTS `user_follow_log_20181116`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181116` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=71330 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181117`
--

DROP TABLE IF EXISTS `user_follow_log_20181117`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181117` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=66305 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181118`
--

DROP TABLE IF EXISTS `user_follow_log_20181118`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181118` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=67067 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181119`
--

DROP TABLE IF EXISTS `user_follow_log_20181119`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181119` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=71731 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181120`
--

DROP TABLE IF EXISTS `user_follow_log_20181120`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181120` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=62922 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181121`
--

DROP TABLE IF EXISTS `user_follow_log_20181121`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181121` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=62703 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181122`
--

DROP TABLE IF EXISTS `user_follow_log_20181122`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181122` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=67833 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181123`
--

DROP TABLE IF EXISTS `user_follow_log_20181123`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181123` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=67681 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181124`
--

DROP TABLE IF EXISTS `user_follow_log_20181124`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181124` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=87691 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181125`
--

DROP TABLE IF EXISTS `user_follow_log_20181125`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181125` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=78419 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181126`
--

DROP TABLE IF EXISTS `user_follow_log_20181126`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181126` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=68549 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181127`
--

DROP TABLE IF EXISTS `user_follow_log_20181127`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181127` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=75395 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181128`
--

DROP TABLE IF EXISTS `user_follow_log_20181128`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181128` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=91124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181129`
--

DROP TABLE IF EXISTS `user_follow_log_20181129`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181129` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=97033 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181130`
--

DROP TABLE IF EXISTS `user_follow_log_20181130`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181130` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=84073 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181201`
--

DROP TABLE IF EXISTS `user_follow_log_20181201`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181201` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=82639 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181202`
--

DROP TABLE IF EXISTS `user_follow_log_20181202`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181202` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=86002 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181203`
--

DROP TABLE IF EXISTS `user_follow_log_20181203`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181203` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=85324 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181204`
--

DROP TABLE IF EXISTS `user_follow_log_20181204`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181204` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=82539 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181205`
--

DROP TABLE IF EXISTS `user_follow_log_20181205`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181205` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=81204 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181206`
--

DROP TABLE IF EXISTS `user_follow_log_20181206`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181206` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=87518 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181207`
--

DROP TABLE IF EXISTS `user_follow_log_20181207`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181207` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=91576 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181208`
--

DROP TABLE IF EXISTS `user_follow_log_20181208`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181208` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=96912 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181209`
--

DROP TABLE IF EXISTS `user_follow_log_20181209`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181209` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=99014 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181210`
--

DROP TABLE IF EXISTS `user_follow_log_20181210`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181210` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=86021 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181211`
--

DROP TABLE IF EXISTS `user_follow_log_20181211`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181211` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=82919 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181212`
--

DROP TABLE IF EXISTS `user_follow_log_20181212`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181212` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=72840 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181213`
--

DROP TABLE IF EXISTS `user_follow_log_20181213`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181213` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=81896 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181214`
--

DROP TABLE IF EXISTS `user_follow_log_20181214`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181214` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=71767 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181215`
--

DROP TABLE IF EXISTS `user_follow_log_20181215`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181215` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=81477 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181216`
--

DROP TABLE IF EXISTS `user_follow_log_20181216`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181216` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=78460 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181217`
--

DROP TABLE IF EXISTS `user_follow_log_20181217`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181217` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=77217 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181218`
--

DROP TABLE IF EXISTS `user_follow_log_20181218`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181218` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=73235 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181219`
--

DROP TABLE IF EXISTS `user_follow_log_20181219`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181219` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=78265 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181220`
--

DROP TABLE IF EXISTS `user_follow_log_20181220`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181220` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=77435 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181221`
--

DROP TABLE IF EXISTS `user_follow_log_20181221`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181221` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=81756 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181222`
--

DROP TABLE IF EXISTS `user_follow_log_20181222`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181222` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=79999 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181223`
--

DROP TABLE IF EXISTS `user_follow_log_20181223`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181223` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=80229 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181224`
--

DROP TABLE IF EXISTS `user_follow_log_20181224`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181224` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=66359 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181225`
--

DROP TABLE IF EXISTS `user_follow_log_20181225`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181225` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=72983 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181226`
--

DROP TABLE IF EXISTS `user_follow_log_20181226`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181226` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=74010 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181227`
--

DROP TABLE IF EXISTS `user_follow_log_20181227`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181227` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=87348 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181228`
--

DROP TABLE IF EXISTS `user_follow_log_20181228`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181228` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=74907 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181229`
--

DROP TABLE IF EXISTS `user_follow_log_20181229`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181229` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=79651 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181230`
--

DROP TABLE IF EXISTS `user_follow_log_20181230`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181230` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=68154 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20181231`
--

DROP TABLE IF EXISTS `user_follow_log_20181231`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20181231` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=62546 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190101`
--

DROP TABLE IF EXISTS `user_follow_log_20190101`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190101` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=58862 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190102`
--

DROP TABLE IF EXISTS `user_follow_log_20190102`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190102` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=63150 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190103`
--

DROP TABLE IF EXISTS `user_follow_log_20190103`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190103` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=75950 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190104`
--

DROP TABLE IF EXISTS `user_follow_log_20190104`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190104` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=66383 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190105`
--

DROP TABLE IF EXISTS `user_follow_log_20190105`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190105` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=76284 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190106`
--

DROP TABLE IF EXISTS `user_follow_log_20190106`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190106` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=69673 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190107`
--

DROP TABLE IF EXISTS `user_follow_log_20190107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190107` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=90275 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190108`
--

DROP TABLE IF EXISTS `user_follow_log_20190108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190108` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=80777 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190109`
--

DROP TABLE IF EXISTS `user_follow_log_20190109`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190109` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=78022 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190110`
--

DROP TABLE IF EXISTS `user_follow_log_20190110`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190110` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=72053 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190111`
--

DROP TABLE IF EXISTS `user_follow_log_20190111`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190111` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=75147 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190112`
--

DROP TABLE IF EXISTS `user_follow_log_20190112`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190112` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=65210 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190716`
--

DROP TABLE IF EXISTS `user_follow_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190716` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=105439 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190717`
--

DROP TABLE IF EXISTS `user_follow_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190717` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=99605 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190718`
--

DROP TABLE IF EXISTS `user_follow_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190718` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=99632 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190720`
--

DROP TABLE IF EXISTS `user_follow_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190720` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=103071 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190721`
--

DROP TABLE IF EXISTS `user_follow_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190721` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=100632 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190722`
--

DROP TABLE IF EXISTS `user_follow_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190722` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=103469 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_follow_log_20190723`
--

DROP TABLE IF EXISTS `user_follow_log_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow_log_20190723` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `follow_type` int(11) NOT NULL COMMENT '1为follow，0为unfollow',
  `source` int(11) DEFAULT NULL COMMENT '1:用户主页，2:推荐列表，3:收藏，4:历史，5:搜索，6:关注精选，7:我的关注，8:微头条，9:文章详情（包活视频，图片），10:用户好友，11:推荐关注，12:外部链接，13:深链自动关注，14:程序自动关注，15:作者介绍，16:文章底部作者推荐',
  `alg_id` int(11) DEFAULT NULL COMMENT '信息流/文章底部作者推荐算法',
  `content_id` bigint(20) DEFAULT NULL COMMENT '列表页/详情页作者关注按钮所在的文章',
  `follow_utc` int(11) NOT NULL,
  `detail` text,
  `resp` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `follow_action` (`user_id`,`author_id`,`follow_type`,`follow_utc`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  KEY `follow_type` (`follow_type`),
  KEY `source` (`source`),
  KEY `alg_id` (`alg_id`),
  KEY `content_id` (`content_id`),
  KEY `resp` (`resp`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_installed_applist_clean_data_tbl`
--

DROP TABLE IF EXISTS `user_installed_applist_clean_data_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_installed_applist_clean_data_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'uid',
  `app_name_id` int(11) NOT NULL COMMENT '对应 app_name_tbl 的id',
  `create_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`,`app_name_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47233153 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_installed_applist_tbl`
--

DROP TABLE IF EXISTS `user_installed_applist_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_installed_applist_tbl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `origin_data` text NOT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=6655296 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_last_action`
--

DROP TABLE IF EXISTS `user_last_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_last_action` (
  `user_id` bigint(20) unsigned NOT NULL,
  `action` varchar(64) NOT NULL,
  `parameter` varchar(2048) DEFAULT NULL,
  `utc_ts` int(11) unsigned NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190716`
--

DROP TABLE IF EXISTS `user_perf_log_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190716` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190717`
--

DROP TABLE IF EXISTS `user_perf_log_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190717` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190718`
--

DROP TABLE IF EXISTS `user_perf_log_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190718` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190720`
--

DROP TABLE IF EXISTS `user_perf_log_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190720` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190721`
--

DROP TABLE IF EXISTS `user_perf_log_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190721` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190722`
--

DROP TABLE IF EXISTS `user_perf_log_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190722` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_perf_log_20190723`
--

DROP TABLE IF EXISTS `user_perf_log_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_perf_log_20190723` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `category` varchar(8) NOT NULL,
  `url` varchar(500) NOT NULL,
  `network` tinyint(4) DEFAULT '0',
  `success` tinyint(4) DEFAULT '1',
  `status_code` smallint(6) DEFAULT '0',
  `used_ms` int(11) DEFAULT '0',
  `extra_ms` int(11) DEFAULT '0',
  `extra_params` varchar(1024) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190716`
--

DROP TABLE IF EXISTS `user_read_alg_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190716` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=11889332 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190717`
--

DROP TABLE IF EXISTS `user_read_alg_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190717` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=11628879 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190718`
--

DROP TABLE IF EXISTS `user_read_alg_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190718` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=11794228 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190720`
--

DROP TABLE IF EXISTS `user_read_alg_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190720` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=10301730 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190721`
--

DROP TABLE IF EXISTS `user_read_alg_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190721` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=10848113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190722`
--

DROP TABLE IF EXISTS `user_read_alg_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190722` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=10989788 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_20190723`
--

DROP TABLE IF EXISTS `user_read_alg_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_20190723` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `read_src` smallint(6) DEFAULT '-1',
  `cat_id` smallint(6) DEFAULT '-1',
  `session_id` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=2524 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_alg_hour_stat`
--

DROP TABLE IF EXISTS `user_read_alg_hour_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_alg_hour_stat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `utc_begin_ts` timestamp NOT NULL,
  `utc_end_ts` timestamp NOT NULL,
  `alg_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL COMMENT 'NULL表示不区分cat_id的一小时统计结果, 否则是对应cat_id的统计',
  `created_local_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `utc_begin_ts` (`utc_begin_ts`),
  KEY `utc_end_ts` (`utc_end_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=2540707 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recall_log`
--

DROP TABLE IF EXISTS `user_recall_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recall_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `last_recall_ts` int(10) unsigned NOT NULL COMMENT '上次召回的时间',
  `recall_ts` int(10) unsigned NOT NULL COMMENT '计算出来的召回时间',
  `deeplink_ts` int(10) unsigned NOT NULL COMMENT '深链上报时间',
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5961048 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190716`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190716` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=159267565 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190717`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190717` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=160846461 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190718`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190718` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=161391460 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190720`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190720` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=143463703 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190721`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190721` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=151089098 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190722`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190722` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=147654682 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_20190723`
--

DROP TABLE IF EXISTS `user_recommend_alg_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_20190723` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(32) NOT NULL DEFAULT '0',
  `cat_id` smallint(6) DEFAULT '0',
  `content_id` bigint(20) NOT NULL,
  `alg_id` smallint(6) DEFAULT '-1',
  `alg_abbr` varchar(256) NOT NULL,
  `alg_scene` varchar(256) DEFAULT NULL,
  `uuid` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=33041 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_recommend_alg_hour_stat`
--

DROP TABLE IF EXISTS `user_recommend_alg_hour_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recommend_alg_hour_stat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `utc_begin_ts` timestamp NOT NULL,
  `utc_end_ts` timestamp NOT NULL,
  `alg_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL COMMENT 'NULL表示不区分cat_id的一小时统计结果, 否则是对应cat_id的统计',
  `created_local_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `utc_begin_ts` (`utc_begin_ts`),
  KEY `utc_end_ts` (`utc_end_ts`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3124589 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_register`
--

DROP TABLE IF EXISTS `user_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_register` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(128) DEFAULT NULL,
  `device_id` varchar(128) DEFAULT NULL,
  `client_ver` varchar(16) NOT NULL,
  `device_model` varchar(64) DEFAULT NULL COMMENT '手机型号',
  `device_os` varchar(64) DEFAULT NULL COMMENT '手机操作系统版本',
  `register_ip` varchar(64) DEFAULT NULL,
  `register_time` int(11) unsigned DEFAULT NULL,
  `cids` varchar(255) DEFAULT NULL,
  `other_cids` varchar(128) DEFAULT NULL,
  `flavor` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11474022 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_retetion_state_update_event_tbl`
--

DROP TABLE IF EXISTS `user_retetion_state_update_event_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_retetion_state_update_event_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `prev_state` smallint(4) NOT NULL,
  `state` smallint(4) NOT NULL,
  `error` varchar(255) NOT NULL,
  `updated_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=295259680 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_tbl`
--

DROP TABLE IF EXISTS `user_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_tbl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `device_id` varchar(128) DEFAULT NULL,
  `device_type` tinyint(4) DEFAULT '0',
  `user_push_id` varchar(256) DEFAULT NULL,
  `facebook_id` varchar(64) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `flavor` varchar(128) DEFAULT NULL,
  `source` tinyint(4) DEFAULT '0',
  `device_os` varchar(16) DEFAULT '',
  `device_model` varchar(64) DEFAULT '',
  `register_ip` varchar(128) DEFAULT '',
  `version` varchar(64) DEFAULT NULL,
  `unique_did` varchar(128) DEFAULT '',
  `imei` varchar(40) DEFAULT NULL,
  `os_rooted` smallint(6) DEFAULT '0',
  `mac_addr` varchar(32) DEFAULT NULL,
  `register_cnt` int(11) NOT NULL DEFAULT '0',
  `user_flavor_unique_id` varchar(64) DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_did` (`device_id`),
  KEY `unique_did` (`unique_did`),
  KEY `mac_addr` (`mac_addr`),
  KEY `flavor` (`flavor`),
  KEY `user_flavor_unique_id` (`user_flavor_unique_id`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=13970525 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190716`
--

DROP TABLE IF EXISTS `video_play_stat_20190716`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190716` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190717`
--

DROP TABLE IF EXISTS `video_play_stat_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190717` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190718`
--

DROP TABLE IF EXISTS `video_play_stat_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190718` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190720`
--

DROP TABLE IF EXISTS `video_play_stat_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190720` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190721`
--

DROP TABLE IF EXISTS `video_play_stat_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190721` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190722`
--

DROP TABLE IF EXISTS `video_play_stat_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190722` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `video_play_stat_20190723`
--

DROP TABLE IF EXISTS `video_play_stat_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_play_stat_20190723` (
  `report_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_ts` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `os` varchar(32) NOT NULL,
  `app_ver` varchar(16) NOT NULL,
  `content_id` int(10) unsigned DEFAULT '0',
  `play_url` varchar(255) DEFAULT '',
  `network` smallint(6) DEFAULT '0',
  `success` smallint(6) DEFAULT '0',
  `source` int(11) DEFAULT '0',
  `seek_position` int(11) DEFAULT '0',
  `buffer_time` int(11) DEFAULT '0',
  `play_time` int(11) DEFAULT '0',
  `page_time` int(11) DEFAULT '0',
  `play_done` smallint(6) DEFAULT '0',
  `reason` int(11) DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `client_ip` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vntopnews_log.user_action_log`
--

DROP TABLE IF EXISTS `vntopnews_log.user_action_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vntopnews_log.user_action_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(256) NOT NULL,
  `action` int(11) NOT NULL,
  `parameter` text,
  `action_time` datetime NOT NULL,
  `ts` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-22 17:14:59
