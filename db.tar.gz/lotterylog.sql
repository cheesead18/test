-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: statistics.lottery.mysql.topnews.com    Database: vntopnews_lotterylog
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `beginner_task_v2_click_journal`
--

DROP TABLE IF EXISTS `beginner_task_v2_click_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_v2_click_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_name` varchar(128) NOT NULL COMMENT '任务名字',
  `click_type` int(11) DEFAULT '0' COMMENT '点击类型，0：表示点击任务引导',
  `click_time` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_click` (`user_id`,`task_name`,`click_type`),
  KEY `task_name` (`task_name`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=456827 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `create_task_condition_v2`
--

DROP TABLE IF EXISTS `create_task_condition_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `create_task_condition_v2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `task_name` varchar(128) NOT NULL COMMENT '任务名字',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_name` (`task_name`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=456200 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_signin_journal`
--

DROP TABLE IF EXISTS `daily_signin_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_signin_journal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `date_str` varchar(10) NOT NULL COMMENT '日期 2018-08-25',
  `signin_time` int(15) unsigned DEFAULT NULL COMMENT '签到时间',
  `signin_times` int(15) unsigned DEFAULT '1' COMMENT '到日签到次数',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date_str_user_id` (`date_str`,`user_id`),
  KEY `created_at` (`created_at`),
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=128893 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_user_journal`
--

DROP TABLE IF EXISTS `daily_task_user_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_user_journal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `task_name` varchar(128) NOT NULL COMMENT '任务名字',
  `finish_time` int(15) unsigned DEFAULT NULL COMMENT '任务完成时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '任务状态 0.任务待完成， 1：任务完成， 2： 任务奖励领取,3:完成任务数，已达上限',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `task_name` (`task_name`),
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=274625 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1071`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1071`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1071` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=570375 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1072`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1072`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1072` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=464667 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1073`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1073`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1073` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=332042 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1074`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1074`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1074` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=352500 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1075`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1075`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1075` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=653573 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1076`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1076`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1076` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1755470 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1077`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1077`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1077` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1435404 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1078`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1078`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1078` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=854355 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1079`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1079`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1079` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=790427 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1080`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1080`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1080` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1034168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1081`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1081`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1081` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1306982 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1082`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1082`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1082` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1676890 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1083`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1083`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1083` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1669466 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1084`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1084`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1084` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1476699 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gen_lottery_num_tbl_1085`
--

DROP TABLE IF EXISTS `gen_lottery_num_tbl_1085`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_lottery_num_tbl_1085` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_no` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=213361 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notify_action_journal`
--

DROP TABLE IF EXISTS `notify_action_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notify_action_journal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `notify_type` varchar(20) NOT NULL,
  `notify_identifier` varchar(60) NOT NULL,
  `action` varchar(10) NOT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `notify_type` (`notify_type`),
  KEY `notify_identifier` (`notify_identifier`),
  KEY `action` (`action`)
) ENGINE=MyISAM AUTO_INCREMENT=4164656 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notify_journal`
--

DROP TABLE IF EXISTS `notify_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notify_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `notify_type` varchar(16) NOT NULL,
  `notify_category` varchar(16) NOT NULL,
  `notify_identifier` varchar(64) NOT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `notify_type` (`notify_type`),
  KEY `notify_category` (`notify_category`),
  KEY `notify_identifier` (`notify_identifier`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=247094 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `questionnaire_tbl`
--

DROP TABLE IF EXISTS `questionnaire_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionnaire_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `age_status` bigint(20) NOT NULL COMMENT ' 1：0-24岁， 2：25-34, 3: 35-44, 4: 45-54, 5: 54 以上',
  `gender` varchar(128) NOT NULL,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `age_status` (`age_status`),
  KEY `gender` (`gender`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=53295 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `read_shared_article_count`
--

DROP TABLE IF EXISTS `read_shared_article_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `read_shared_article_count` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `shared_uid` bigint(20) NOT NULL COMMENT '分享文章的用户ID',
  `content_id` bigint(20) DEFAULT NULL,
  `shared_dest` varchar(128) DEFAULT NULL COMMENT 'unknow, facebook, zero',
  `readcount` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shared_uid` (`shared_uid`,`content_id`,`shared_dest`),
  KEY `content_id` (`content_id`),
  KEY `created_at` (`created_at`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=15090858 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `read_shared_webview_count`
--

DROP TABLE IF EXISTS `read_shared_webview_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `read_shared_webview_count` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `shared_uid` bigint(20) NOT NULL COMMENT '分享文章的用户ID',
  `webview_name` varchar(128) NOT NULL COMMENT 'webview name',
  `shared_dest` varchar(128) DEFAULT NULL COMMENT 'facebook, zero',
  `readcount` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shared_uid` (`shared_uid`,`webview_name`,`shared_dest`),
  KEY `webview_name` (`webview_name`),
  KEY `created_at` (`created_at`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=744515 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recover_install_stat`
--

DROP TABLE IF EXISTS `recover_install_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recover_install_stat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `total_minus_coins` int(11) DEFAULT '0',
  `total_valid_coins` int(11) DEFAULT '0',
  `sucess_consume_coins` int(11) DEFAULT '0',
  `total_money_coins` int(11) DEFAULT '0',
  `level1_minus_coins` int(11) DEFAULT '0',
  `level2_minus_coins` int(11) DEFAULT '0',
  `level3_minus_coins` int(11) DEFAULT '0',
  `level1_trainee_num` int(11) DEFAULT '0',
  `level2_trainee_num` int(11) DEFAULT '0',
  `level3_trainee_num` int(11) DEFAULT '0',
  `treasure_munus_coins` int(11) DEFAULT '0',
  `cheat_beg_time` int(11) DEFAULT '0',
  `cheat_end_time` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=477 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `share_page_user_phone`
--

DROP TABLE IF EXISTS `share_page_user_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_page_user_phone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `phone` varchar(64) NOT NULL,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=5223 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `share_page_visit_cnt`
--

DROP TABLE IF EXISTS `share_page_visit_cnt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_page_visit_cnt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ds` varchar(10) NOT NULL,
  `channel` varchar(64) NOT NULL,
  `floor_page` varchar(64) NOT NULL,
  `visit_cnt` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ds` (`ds`,`channel`,`floor_page`)
) ENGINE=MyISAM AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `share_report_journal`
--

DROP TABLE IF EXISTS `share_report_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_report_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `channel` varchar(64) NOT NULL COMMENT '分享渠道',
  `share_page` varchar(64) NOT NULL COMMENT '分享的页面',
  `floor_page` varchar(64) NOT NULL DEFAULT '',
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `channel` (`channel`),
  KEY `share_page` (`share_page`),
  KEY `created_ts` (`created_ts`),
  KEY `floor_page` (`floor_page`)
) ENGINE=MyISAM AUTO_INCREMENT=4660952 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_app_push_journey`
--

DROP TABLE IF EXISTS `user_app_push_journey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_app_push_journey` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `push_reason` varchar(128) NOT NULL COMMENT '文章（活动）分享阅读推送，收徒推送',
  `push_detail_id` int(11) DEFAULT NULL COMMENT '推送内容详情表ID，to do.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `app_push_enum` int(11) NOT NULL COMMENT '1,shared article read 2,shared webviews read 3, get trainee',
  `sucess` int(11) DEFAULT NULL COMMENT '推送是否成功',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=19688491 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_failed_ex_phone_card`
--

DROP TABLE IF EXISTS `user_failed_ex_phone_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_failed_ex_phone_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `isp_company` varchar(64) NOT NULL COMMENT '充值卡所属公司:gmobile viettel mobifone vinaphone vietnamobile',
  `denomination` bigint(20) NOT NULL COMMENT '面额VND',
  `enum` int(11) NOT NULL COMMENT '1: 电话卡池中没有可兑换的电话卡',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  KEY `isp_company` (`isp_company`),
  KEY `denomination` (`denomination`)
) ENGINE=MyISAM AUTO_INCREMENT=497237 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_income_msg_status_tbl`
--

DROP TABLE IF EXISTS `user_income_msg_status_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_income_msg_status_tbl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `msg_content_enum` int(11) NOT NULL,
  `message_id` varchar(128) DEFAULT NULL,
  `last_push_time` datetime NOT NULL,
  `success` int(11) DEFAULT NULL COMMENT '推送是否成功',
  `extra_json` varchar(2048) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_m_c_enum` (`user_id`,`msg_content_enum`),
  KEY `created_at` (`created_at`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=378745 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_last_history_online_time`
--

DROP TABLE IF EXISTS `user_last_history_online_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_last_history_online_time` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `last_online_utc` bigint(20) NOT NULL COMMENT '一小时前最后一次在线时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `last_online_utc` (`last_online_utc`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=8943297 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-22 16:51:28
