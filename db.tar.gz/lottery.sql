-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: statistics.lottery.mysql.topnews.com    Database: vntopnews_lottery
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allowance_for_mart_upgrade`
--

DROP TABLE IF EXISTS `allowance_for_mart_upgrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowance_for_mart_upgrade` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `coin` int(11) unsigned NOT NULL,
  `status` int(11) DEFAULT '0' COMMENT '0:未领取,1:已领取',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=504168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `answer_tbl`
--

DROP TABLE IF EXISTS `answer_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `statement` text,
  `choices` varchar(128) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_question_id` (`user_id`,`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=441387 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_config_tbl`
--

DROP TABLE IF EXISTS `beginner_task_config_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_config_tbl` (
  `task_id` int(11) NOT NULL COMMENT '任务 id',
  `task_name` varchar(30) NOT NULL COMMENT '任务名字',
  `summary` varchar(255) NOT NULL COMMENT '任务简述',
  `enabled` tinyint(4) NOT NULL COMMENT '是否开启 0: 关闭, 1: 开启',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_record_tbl`
--

DROP TABLE IF EXISTS `beginner_task_record_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_record_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `task_id` int(11) NOT NULL COMMENT '任务 id',
  `task_name` varchar(255) NOT NULL COMMENT '任务名字',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '任务状态 0: 未完成, 1: 已经完成, 2: 已经领取任务奖励',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_and_task_id` (`user_id`,`task_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3769980 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_record_tbl_bak`
--

DROP TABLE IF EXISTS `beginner_task_record_tbl_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_record_tbl_bak` (
  `uid` bigint(22) NOT NULL,
  `first_login` tinyint(2) NOT NULL DEFAULT '0' COMMENT '登录过 （0:未完成，1:已完成，2:已领取）',
  `read_news` tinyint(2) NOT NULL DEFAULT '0' COMMENT '阅读过文章（0:未完成，1:已完成，2:已领取）',
  `bind_phone` tinyint(2) NOT NULL DEFAULT '0' COMMENT '绑定手机',
  `exchange_coin2cash` tinyint(2) NOT NULL DEFAULT '0' COMMENT '用金币兑换现金',
  `got_10_exp` tinyint(2) NOT NULL DEFAULT '0' COMMENT '获取 10 经验',
  `active_3_days` tinyint(2) NOT NULL DEFAULT '0' COMMENT '活跃 3 天',
  `active_7_days` tinyint(2) NOT NULL DEFAULT '0' COMMENT '活跃 7 天',
  `got_phone_card` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否领取电话卡（0:未领取，1:已领取）',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `fb_share` tinyint(2) NOT NULL DEFAULT '0' COMMENT 'fb 分享',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_user_info_tbl`
--

DROP TABLE IF EXISTS `beginner_task_user_info_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_user_info_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `got_phone_card` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否获得新手电话卡',
  `expired_ts` datetime DEFAULT NULL COMMENT '超时的时间',
  `got_phone_card_time` datetime DEFAULT NULL COMMENT '得到电话卡的时间',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=427378 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_v2_config_tbl`
--

DROP TABLE IF EXISTS `beginner_task_v2_config_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_v2_config_tbl` (
  `task_name` varchar(30) NOT NULL COMMENT '任务名字',
  `title` varchar(512) DEFAULT '' COMMENT '任务标题',
  `summary` varchar(512) NOT NULL COMMENT '任务简述',
  `enabled` tinyint(4) NOT NULL COMMENT '是否开启 0: 关闭, 1: 开启',
  `level_id` int(11) NOT NULL COMMENT '开放展示顺序: 1、2、3...',
  `level_priority` int(11) NOT NULL DEFAULT '1' COMMENT '每一层的优先顺序 1.2.3...',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `event_id` int(11) DEFAULT NULL COMMENT '奖励类型对应的event_id',
  `ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_v2_level_config_tbl`
--

DROP TABLE IF EXISTS `beginner_task_v2_level_config_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_v2_level_config_tbl` (
  `level_id` int(11) NOT NULL COMMENT '开放展示顺序ID, beg 1 to 2 3 4 5',
  `level_process` varchar(64) NOT NULL DEFAULT '1' COMMENT 'all:这个层级的任务需要全部完成才开放下一个层级；one: 这个层级的任务只需要完成一个就能开发下一个层级',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_v2_record_tbl`
--

DROP TABLE IF EXISTS `beginner_task_v2_record_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_v2_record_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `task_name` varchar(255) NOT NULL COMMENT '任务名字',
  `status` tinyint(2) NOT NULL DEFAULT '-1' COMMENT '任务状态 -1,没有开启的任务, 0: 未完成, 1: 已经完成, 2: 已经领取任务奖励',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_and_task_id` (`user_id`,`task_name`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `task_name` (`task_name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=28161336 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `beginner_task_v2_user_info_tbl`
--

DROP TABLE IF EXISTS `beginner_task_v2_user_info_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beginner_task_v2_user_info_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `max_show_level` int(11) NOT NULL DEFAULT '1' COMMENT '当前开放的最大level',
  `be_invited` tinyint(4) NOT NULL COMMENT '是否是邀请的徒弟',
  `expired_ts` datetime DEFAULT NULL COMMENT '超时的时间',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `invited_enum` tinyint(4) DEFAULT '0' COMMENT '0: 未知，1：师徒邀请新手任务，2：自然安装',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14458474 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `coin_event_id`
--

DROP TABLE IF EXISTS `coin_event_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin_event_id` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` smallint(6) NOT NULL,
  `direction` varchar(64) NOT NULL,
  `en_desc` varchar(128) CHARACTER SET utf8mb4 DEFAULT NULL,
  `cn_desc` varchar(512) CHARACTER SET utf8mb4 DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  `need_pet_add` int(11) DEFAULT '0' COMMENT '发财树是否加成0，不加成，1：加成',
  `need_master_income_add` int(11) DEFAULT '0' COMMENT '是否需要师徒收益加成，0，不加成，1：加成',
  `invalid` int(11) DEFAULT '0' COMMENT '0: 正常event_id，可以执行金币的增减； 非0: 表示无效event_id，不执行金币的增减',
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`),
  KEY `direction` (`direction`)
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_sign_in_journal`
--

DROP TABLE IF EXISTS `daily_sign_in_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_sign_in_journal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date_str` varchar(8) DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  `c_day` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`date_str`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=29804839 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_sign_in_user_stat`
--

DROP TABLE IF EXISTS `daily_sign_in_user_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_sign_in_user_stat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '连续签到天数',
  `c_day` int(10) unsigned DEFAULT '0',
  `last_sign_date_str` varchar(8) DEFAULT NULL,
  `ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10685661 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_config_tbl`
--

DROP TABLE IF EXISTS `daily_task_config_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_config_tbl` (
  `task_name` varchar(128) NOT NULL COMMENT '任务名字',
  `summary` varchar(255) NOT NULL COMMENT '任务简述',
  `enabled` tinyint(4) NOT NULL COMMENT '是否开启 0: 关闭, 1: 开启',
  `period` int(11) NOT NULL COMMENT '单位秒，任务周期,如果是天的整数倍，则对齐0时刻',
  `priority` int(11) NOT NULL COMMENT '展示顺序 1 2 3 ...',
  `max_times` int(11) DEFAULT NULL COMMENT '每个用户常规任务最大次数',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp lottery',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_user_curr_info_tbl`
--

DROP TABLE IF EXISTS `daily_task_user_curr_info_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_user_curr_info_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(22) NOT NULL,
  `task_name` varchar(128) NOT NULL COMMENT '任务名字',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '任务状态 0.任务待完成， 1：任务完成， 2： 任务奖励领取,3:完成任务数，已达上限',
  `finish_time` int(15) unsigned DEFAULT NULL COMMENT '任务完成时间',
  `finish_times` int(11) DEFAULT '0' COMMENT '当前用户完成任务的次数',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_and_task_name` (`user_id`,`task_name`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11728898 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `delay_append_coin`
--

DROP TABLE IF EXISTS `delay_append_coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delay_append_coin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from_uid` bigint(20) NOT NULL,
  `to_uid` bigint(20) NOT NULL,
  `event_id` smallint(6) NOT NULL,
  `direction` varchar(16) CHARACTER SET latin1 NOT NULL,
  `number` double(16,5) NOT NULL,
  `memo` varchar(1024) CHARACTER SET latin1 NOT NULL,
  `status` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '0: 未到账 1:已经到账',
  `last_check_ts` datetime DEFAULT NULL,
  `check_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `from_uid` (`from_uid`),
  KEY `to_uid` (`to_uid`),
  KEY `event_id` (`event_id`),
  KEY `status` (`status`),
  KEY `last_check_ts` (`last_check_ts`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=1311699 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `delay_new_trainee_reward`
--

DROP TABLE IF EXISTS `delay_new_trainee_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delay_new_trainee_reward` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `trainee_tbl_offset` bigint(20) NOT NULL,
  `master_id` bigint(20) NOT NULL,
  `trainee_id` bigint(20) NOT NULL,
  `rewarded` tinyint(4) NOT NULL DEFAULT '0',
  `update_ts` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trainee_tbl_offset` (`trainee_tbl_offset`),
  UNIQUE KEY `master_id_2` (`master_id`,`trainee_id`),
  KEY `master_id` (`master_id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `rewarded` (`rewarded`)
) ENGINE=MyISAM AUTO_INCREMENT=516653 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exchange_phone_card_cheat_bak`
--

DROP TABLE IF EXISTS `exchange_phone_card_cheat_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange_phone_card_cheat_bak` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `ph_enum` smallint(6) DEFAULT NULL COMMENT '1,2,3三种电话卡',
  `number` smallint(6) DEFAULT NULL COMMENT '兑换电话卡的张数',
  `provide_stat` smallint(6) DEFAULT '2' COMMENT '2: 还没有发放给用户，未到账; 1: 已经发放给用户',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `provide_utc` int(11) DEFAULT NULL,
  `cheat_proc_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `money` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=703 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fake_train_stat_tbl`
--

DROP TABLE IF EXISTS `fake_train_stat_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fake_train_stat_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `fake_trainee_id` int(11) unsigned DEFAULT NULL COMMENT '满足赠送假徒弟规则前为NULL',
  `fake_trainee_invalid` int(11) DEFAULT '0' COMMENT '非0表示不再考虑送假徒弟',
  `master_created_at` timestamp NOT NULL COMMENT '用户创建时间',
  `fake_trainee_created_at` timestamp NULL DEFAULT NULL COMMENT '假徒弟创建时间',
  `shared_page_num` int(11) DEFAULT NULL COMMENT '送徒弟时分享文章的次数',
  `coin_summary` double(16,5) DEFAULT '0.00000' COMMENT '假徒弟(按照普通赠送规则)当前金币总贡献值,可能与master_trainee_contribution表不同',
  `exp_summary` double(16,5) DEFAULT '0.00000' COMMENT '假徒弟(按照普通赠送规则)当前经验总贡献值',
  `exp_total_time` int(11) DEFAULT '0' COMMENT '安装假徒弟送经验的通用规则送的总次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_id` (`master_id`),
  UNIQUE KEY `fake_trainee_id` (`fake_trainee_id`),
  KEY `master_created_at` (`master_created_at`),
  KEY `fake_trainee_created_at` (`fake_trainee_created_at`),
  KEY `fake_trainee_invalid` (`fake_trainee_invalid`)
) ENGINE=MyISAM AUTO_INCREMENT=2917381 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fake_train_stat_v3_tbl`
--

DROP TABLE IF EXISTS `fake_train_stat_v3_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fake_train_stat_v3_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `master_created_at` timestamp NOT NULL COMMENT '用户创建时间',
  `last_give_time` timestamp NULL DEFAULT NULL COMMENT '最近一次送假徒弟的时间',
  `fake_trainee_num` int(11) DEFAULT '0' COMMENT '假徒弟数据',
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_id` (`master_id`),
  KEY `fake_trainee_num` (`fake_trainee_num`)
) ENGINE=MyISAM AUTO_INCREMENT=2639598 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fb_share_record_tbl`
--

DROP TABLE IF EXISTS `fb_share_record_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fb_share_record_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `create_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'UTC0 时间',
  `source_page` varchar(64) NOT NULL DEFAULT '' COMMENT '分享来 源',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `source_page` (`source_page`),
  KEY `create_ts` (`create_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=3008949 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `first_trainee_sign_in`
--

DROP TABLE IF EXISTS `first_trainee_sign_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `first_trainee_sign_in` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) unsigned NOT NULL,
  `date_str` varchar(8) DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_id` (`master_id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `date_str` (`date_str`)
) ENGINE=MyISAM AUTO_INCREMENT=476333 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `first_trainee_task_com_sub_task_record`
--

DROP TABLE IF EXISTS `first_trainee_task_com_sub_task_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `first_trainee_task_com_sub_task_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) unsigned NOT NULL,
  `day` int(10) unsigned NOT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_id` (`master_id`,`day`),
  KEY `trainee_id` (`trainee_id`),
  KEY `day` (`day`)
) ENGINE=MyISAM AUTO_INCREMENT=2339 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `first_trainee_task_record`
--

DROP TABLE IF EXISTS `first_trainee_task_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `first_trainee_task_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `begin_ts` int(10) unsigned NOT NULL,
  `date_str` varchar(8) NOT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18976 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gradient_task_config_tbl`
--

DROP TABLE IF EXISTS `gradient_task_config_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gradient_task_config_tbl` (
  `task_id` int(11) NOT NULL COMMENT '任务ID',
  `title` varchar(512) DEFAULT '' COMMENT '任务标题',
  `summary` varchar(512) NOT NULL COMMENT '任务简述',
  `enable` tinyint(4) DEFAULT '1' COMMENT '是否开启 0: 关闭, 1: 开启',
  `need_trainee` int(11) DEFAULT NULL COMMENT '总达到的徒弟数',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp（这里的奖励，是梯度奖励，总奖励=所有满足收徒要求任务的梯度奖励）',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `event_id` int(11) DEFAULT NULL COMMENT '奖励类型对应的event_id',
  `ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_id`),
  KEY `task_id` (`task_id`),
  KEY `enable` (`enable`),
  KEY `need_trainee` (`need_trainee`),
  KEY `reward_type` (`reward_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gradient_task_curr_period_record_tbl`
--

DROP TABLE IF EXISTS `gradient_task_curr_period_record_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gradient_task_curr_period_record_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period_name` varchar(30) NOT NULL COMMENT '任务名字',
  `user_id` bigint(22) NOT NULL,
  `task_id` int(11) NOT NULL COMMENT '任务ID',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0: 未完成, 1: 已经完成, 2: 已经领取任务奖励',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_and_task_id` (`user_id`,`task_id`) USING BTREE,
  KEY `period_name` (`period_name`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `task_id` (`task_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `created_at` (`created_at`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=133885 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gradient_task_period_journal_tbl`
--

DROP TABLE IF EXISTS `gradient_task_period_journal_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gradient_task_period_journal_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period_name` varchar(30) NOT NULL COMMENT '任务名字',
  `user_id` bigint(22) NOT NULL,
  `task_id` int(11) NOT NULL COMMENT '任务ID',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0: 未完成, 1: 已经完成, 2: 已经领取任务奖励',
  `reward_type` varchar(30) DEFAULT NULL COMMENT '奖励类型 xu exp',
  `reward_amount` int(11) DEFAULT NULL COMMENT '奖励数量',
  `ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_and_period_name_task_id` (`user_id`,`period_name`,`task_id`) USING BTREE,
  KEY `period_name` (`period_name`) USING BTREE,
  KEY `task_id` (`task_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `created_at` (`created_at`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=158134 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gradient_task_period_user_info`
--

DROP TABLE IF EXISTS `gradient_task_period_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gradient_task_period_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `period_name` varchar(30) NOT NULL,
  `avg_trainee_cnt` int(10) unsigned DEFAULT '0',
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`period_name`)
) ENGINE=MyISAM AUTO_INCREMENT=54279 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invite_code_bind`
--

DROP TABLE IF EXISTS `invite_code_bind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite_code_bind` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `invite_code` varchar(8) NOT NULL,
  `inviter_user_id` bigint(20) NOT NULL,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`invite_code`),
  KEY `user_id_2` (`user_id`),
  KEY `invite_code` (`invite_code`),
  KEY `created_ts` (`created_ts`),
  KEY `inviter_user_id` (`inviter_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1423619 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lottery_participant`
--

DROP TABLE IF EXISTS `lottery_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lottery_participant` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `issue_no` int(11) unsigned NOT NULL,
  `lottery_num` int(11) unsigned NOT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `action_enum` int(11) DEFAULT '1',
  `sid` varchar(128) DEFAULT NULL COMMENT '流水账号 vn_timestr+uid+rand(9999)',
  `pet_sid` varchar(128) DEFAULT NULL,
  `pet_lottery_num` int(11) unsigned DEFAULT NULL,
  `parent_sid` varchar(128) DEFAULT NULL COMMENT '宠物流水对应的主流水',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lottery_num` (`lottery_num`,`issue_no`),
  KEY `user_id` (`user_id`,`issue_no`),
  KEY `issue_no` (`issue_no`)
) ENGINE=MyISAM AUTO_INCREMENT=59432533 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lottery_participant_cheat_bak`
--

DROP TABLE IF EXISTS `lottery_participant_cheat_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lottery_participant_cheat_bak` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `issue_no` int(11) unsigned NOT NULL,
  `lottery_num` int(11) unsigned NOT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `action_enum` int(11) DEFAULT '1',
  `cheat_proc_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lottery_num` (`lottery_num`,`issue_no`)
) ENGINE=MyISAM AUTO_INCREMENT=12685 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lottery_tbl`
--

DROP TABLE IF EXISTS `lottery_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lottery_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '期号',
  `begin_time` int(11) unsigned NOT NULL COMMENT '开始时间',
  `end_time` int(11) unsigned NOT NULL COMMENT '结束时间',
  `lottery_time` int(11) unsigned NOT NULL COMMENT '开奖时间',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1139 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lottery_winner`
--

DROP TABLE IF EXISTS `lottery_winner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lottery_winner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `issue_no` int(11) unsigned NOT NULL,
  `invalid` int(11) NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lottery_num` int(11) unsigned DEFAULT NULL,
  `third_lottery_num` int(11) unsigned DEFAULT '0' COMMENT '越南彩票开奖号码',
  `third_time` varchar(64) DEFAULT '' COMMENT '越南彩票开奖时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`issue_no`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_class_info`
--

DROP TABLE IF EXISTS `master_class_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_class_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `class_id` int(10) unsigned NOT NULL COMMENT '用户类别',
  `class` varchar(128) NOT NULL,
  `memo` varchar(1024) NOT NULL,
  `update_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `class_id` (`class_id`),
  KEY `update_ts` (`update_ts`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=8650 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_income_topn`
--

DROP TABLE IF EXISTS `master_income_topn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_income_topn` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `rank_num` int(11) unsigned NOT NULL COMMENT '排名',
  `trainee_num` int(11) unsigned NOT NULL,
  `total_contribution_value` int(11) NOT NULL COMMENT '所有徒弟的贡献值',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatar` varchar(1024) DEFAULT NULL,
  `province` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_id` (`master_id`),
  KEY `rank_num` (`rank_num`),
  KEY `trainee_num` (`trainee_num`),
  KEY `total_contribution_value` (`total_contribution_value`)
) ENGINE=MyISAM AUTO_INCREMENT=60450227 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_info`
--

DROP TABLE IF EXISTS `master_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `login_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0:未登录,1已登录',
  `nickname` varchar(128) NOT NULL,
  `offer_coin` int(11) unsigned NOT NULL,
  `trainee_count` int(11) unsigned NOT NULL,
  `first_trainee_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_trainee_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10278 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee`
--

DROP TABLE IF EXISTS `master_trainee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `trainee_id` int(11) unsigned NOT NULL,
  `type` int(11) DEFAULT '0',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `device_id` varchar(128) DEFAULT NULL,
  `source` varchar(64) DEFAULT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `contribution_value` float(10,2) DEFAULT NULL COMMENT '徒弟对师父的综合贡献值',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `master_id` (`master_id`),
  KEY `trainee_id` (`trainee_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13977 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_bonus_tbl`
--

DROP TABLE IF EXISTS `master_trainee_bonus_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_bonus_tbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) unsigned NOT NULL,
  `bonus_type` varchar(16) NOT NULL COMMENT '收徒奖励方案',
  `bonus_cnt` int(10) unsigned DEFAULT '0' COMMENT '收徒奖励次数',
  `bonus_sum` int(10) unsigned DEFAULT '0' COMMENT '收徒奖励累计（VND）',
  `bonus_max` int(10) unsigned NOT NULL COMMENT '收徒最大奖励（VND）',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trainee_id` (`trainee_id`),
  KEY `master_id` (`master_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1524108 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_cheater`
--

DROP TABLE IF EXISTS `master_trainee_cheater`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_cheater` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=30896 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_contribution`
--

DROP TABLE IF EXISTS `master_trainee_contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_contribution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `trainee_id` int(11) unsigned NOT NULL,
  `contribution_enum` varchar(128) NOT NULL COMMENT 'xu exp iphone_lottery 分别表示金币、经验、奖券',
  `total_quantity` double(16,5) unsigned NOT NULL DEFAULT '0.00000' COMMENT 'contribution_enum 对应的数量',
  `history_quantity` double(16,5) unsigned NOT NULL DEFAULT '0.00000' COMMENT '历史收益',
  `is_pet` int(11) NOT NULL DEFAULT '0' COMMENT '是否为宠物收益',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_id_2` (`master_id`,`trainee_id`,`contribution_enum`),
  KEY `master_id` (`master_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `total_quantity` (`total_quantity`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=20045 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_contribution_journey`
--

DROP TABLE IF EXISTS `master_trainee_contribution_journey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_contribution_journey` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `trainee_id` int(11) unsigned NOT NULL,
  `contribution_enum` varchar(128) NOT NULL COMMENT 'xu exp iphone_lottery 分别表示金币、经验、奖券',
  `quantity` double(16,5) unsigned NOT NULL COMMENT 'contribution_enum 对应的数量',
  `trainee_journey_sid` varchar(128) NOT NULL COMMENT '徒弟contribution_enum对应流水表中的账号， 防止重复赠送',
  `contribution_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `master_id` (`master_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `trainee_journey_sid` (`trainee_journey_sid`),
  KEY `contribution_utc` (`contribution_utc`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=674402 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_contribution_pyramid_error_journey`
--

DROP TABLE IF EXISTS `master_trainee_contribution_pyramid_error_journey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_contribution_pyramid_error_journey` (
  `id` bigint(20) NOT NULL,
  `master_id` int(11) unsigned NOT NULL,
  `trainee_id` int(11) unsigned NOT NULL,
  `master_level` int(11) unsigned NOT NULL COMMENT '1.表示直接师父，2.表示师父的师父...',
  `contribution_enum` varchar(128) NOT NULL COMMENT 'xu exp iphone_lottery 分别表示金币、经验、奖券',
  `quantity` float(16,5) unsigned NOT NULL COMMENT 'contribution_enum 对应的数量',
  `trainee_journey_sid` varchar(128) NOT NULL COMMENT '徒弟contribution_enum对应流水表中的账号， 防止重复赠送',
  `event_id` int(11) NOT NULL COMMENT 'xu exp iphone_lottery 中的 event_id or action_enum',
  `contribution_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `master_id` (`master_id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `trainee_journey_sid` (`trainee_journey_sid`),
  KEY `event_id` (`event_id`),
  KEY `contribution_utc` (`contribution_utc`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_contribution_pyramid_journey`
--

DROP TABLE IF EXISTS `master_trainee_contribution_pyramid_journey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_contribution_pyramid_journey` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) unsigned NOT NULL,
  `trainee_id` int(11) unsigned NOT NULL,
  `master_level` int(11) unsigned NOT NULL COMMENT '1.表示直接师父，2.表示师父的师父...',
  `contribution_enum` varchar(128) NOT NULL COMMENT 'xu exp iphone_lottery 分别表示金币、经验、奖券',
  `quantity` float(16,5) unsigned NOT NULL COMMENT 'contribution_enum 对应的数量',
  `trainee_journey_sid` varchar(128) NOT NULL COMMENT '徒弟contribution_enum对应流水表中的账号， 防止重复赠送',
  `event_id` int(11) NOT NULL COMMENT 'xu exp iphone_lottery 中的 event_id or action_enum',
  `contribution_utc` int(11) NOT NULL COMMENT '贡献时间取值徒弟流水中的event_ts或created_at',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `master_event_id` int(11) DEFAULT NULL COMMENT '师父收益的event_id or action_enum',
  `master_journey_sid` varchar(128) DEFAULT NULL COMMENT '师父收益流水SID or action_enum',
  `pet_expected_quantity` float(16,5) unsigned DEFAULT NULL COMMENT '宠物树期望的加成值',
  `pet_journey_sid` varchar(128) DEFAULT NULL COMMENT '宠物树加成时的sid or action_enum',
  PRIMARY KEY (`id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `trainee_journey_sid` (`trainee_journey_sid`),
  KEY `contribution_utc` (`contribution_utc`),
  KEY `master_journey_sid` (`master_journey_sid`),
  KEY `pet_journey_sid` (`pet_journey_sid`),
  KEY `pet_expected_quantity` (`pet_expected_quantity`),
  KEY `master_ts` (`master_id`,`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=202130192 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_income_counter`
--

DROP TABLE IF EXISTS `master_trainee_income_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_income_counter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `counter_enum` varchar(128) NOT NULL COMMENT 'xu exp iphone_lottery 流水计算信息辅助',
  `beg_process_id` bigint(20) NOT NULL COMMENT '计算前获取流水上次设置的开始点，并且设置当前curr_max_id',
  `curr_max_id` bigint(20) NOT NULL COMMENT '计算后，通过curr_max_id结合分表机制设置下次开始点',
  `journey_table_name` varchar(128) DEFAULT NULL COMMENT '计算后，通过分表机制设置下次计算的流水表',
  PRIMARY KEY (`id`),
  UNIQUE KEY `counter_enum` (`counter_enum`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_pyramid_contribution`
--

DROP TABLE IF EXISTS `master_trainee_pyramid_contribution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_pyramid_contribution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `trainee_id` int(11) unsigned NOT NULL,
  `master_id` int(11) unsigned DEFAULT NULL COMMENT 'master_level 对应的师傅ID',
  `master_level` int(11) unsigned NOT NULL,
  `contribution_enum` varchar(128) NOT NULL COMMENT 'xu exp iphone_lottery 分别表示金币、经验、奖券',
  `total_quantity` float(16,5) unsigned NOT NULL DEFAULT '0.00000' COMMENT 'contribution_enum 对应的数量',
  `history_quantity` float(16,5) unsigned NOT NULL DEFAULT '0.00000' COMMENT '历史收益',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trainee_id_master` (`trainee_id`,`master_id`,`contribution_enum`),
  KEY `master_level` (`master_level`),
  KEY `master_id` (`master_id`),
  KEY `contribution_enum` (`contribution_enum`),
  KEY `total_quantity` (`total_quantity`),
  KEY `created_at` (`created_at`),
  KEY `query_contri` (`master_id`,`contribution_enum`,`master_level`,`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=7579479 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_pyramid_relationship`
--

DROP TABLE IF EXISTS `master_trainee_pyramid_relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_pyramid_relationship` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `trainee_id` int(11) unsigned NOT NULL,
  `master_id` int(11) unsigned DEFAULT NULL COMMENT 'master_level 对应的师傅ID',
  `master_level` int(11) unsigned NOT NULL,
  `type` int(11) DEFAULT '0' COMMENT '1: 新手任务上线前的司徒关系, 2:新手任务上线后的司徒关系， 99: 假徒弟, 100: master_trainee中的旧徒弟',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trainee_id_master` (`trainee_id`,`master_id`,`master_level`),
  KEY `master_level` (`master_level`),
  KEY `master_id` (`master_id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=21627296 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_v2`
--

DROP TABLE IF EXISTS `master_trainee_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_v2` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) NOT NULL,
  `device_id` varchar(128) DEFAULT NULL,
  `source` varchar(64) DEFAULT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '0: 新手任务上线前的司徒关系, 1:新手任务上线后的司徒关系， 99: 假徒弟',
  `contribution_value` double(16,5) DEFAULT NULL COMMENT '徒弟对师父的综合贡献值',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `root_master_id` bigint(20) unsigned DEFAULT NULL COMMENT 'trainee_id对应的根师父，NULL未知，0表示没有师父',
  `root_master_depth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trainee_id` (`trainee_id`),
  KEY `type` (`type`),
  KEY `contribution_value` (`contribution_value`),
  KEY `ts` (`ts`),
  KEY `created_at` (`created_at`),
  KEY `root_master_id` (`root_master_id`),
  KEY `master_id` (`master_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6656221 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_trainee_v2_invalid`
--

DROP TABLE IF EXISTS `master_trainee_v2_invalid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_trainee_v2_invalid` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) NOT NULL,
  `device_id` varchar(128) DEFAULT NULL,
  `source` varchar(64) DEFAULT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '0: 新手任务上线前的司徒关系, 1:新手任务上线后的司徒关系， 99: 假徒弟',
  `invalid_reason` varchar(256) DEFAULT '' COMMENT '无效原因',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=2377680 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `old_master_tbl`
--

DROP TABLE IF EXISTS `old_master_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_master_tbl` (
  `master_id` bigint(20) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operating_journal`
--

DROP TABLE IF EXISTS `operating_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operating_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `op_user` varchar(128) NOT NULL COMMENT '操作人员',
  `op_action` varchar(128) NOT NULL COMMENT '动作',
  `op_cat` varchar(128) NOT NULL COMMENT '操作的类别',
  `op_target_id` bigint(20) NOT NULL COMMENT '操作目标 id',
  `memo` varchar(128) NOT NULL DEFAULT '',
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `op_user` (`op_user`),
  KEY `op_cat` (`op_cat`),
  KEY `created_ts` (`created_ts`),
  KEY `op_action` (`op_action`),
  KEY `op_target_id` (`op_target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `question_tbl`
--

DROP TABLE IF EXISTS `question_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text NOT NULL,
  `choices` text,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `survey_id` (`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `score_event_id`
--

DROP TABLE IF EXISTS `score_event_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_event_id` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` smallint(6) NOT NULL,
  `direction` varchar(64) NOT NULL,
  `en_desc` varchar(128) CHARACTER SET utf8mb4 DEFAULT NULL,
  `cn_desc` varchar(512) CHARACTER SET utf8mb4 DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`),
  KEY `direction` (`direction`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `self_spread_enable_config`
--

DROP TABLE IF EXISTS `self_spread_enable_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `self_spread_enable_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `begin_id` bigint(20) NOT NULL,
  `end_id` bigint(20) NOT NULL,
  `permit_flavor` varchar(4096) DEFAULT NULL COMMENT 'NULL表示不限制，json dumps ["main","tin"]',
  `min_permit_version` varchar(128) DEFAULT '1.11.0' COMMENT 'APP 最低版本',
  `extra_json` text NOT NULL COMMENT 'master_and_trainee：各级师父的收徒金币收益（level:income; json dumps：{1:30, 2:20, 3:10}）; red_pacekt: ...',
  `config_type` int(11) NOT NULL DEFAULT '1' COMMENT '默认配置为0,默认灰度群',
  `category` varchar(32) NOT NULL COMMENT '配置类型： master_and_trainee, red_pacekt, pet, eg.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shared_visitor_counter`
--

DROP TABLE IF EXISTS `shared_visitor_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shared_visitor_counter` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `visit_count` int(10) unsigned DEFAULT '0',
  `visit_bonus` int(10) unsigned DEFAULT '0' COMMENT 'VND',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15163 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_journey_tbl`
--

DROP TABLE IF EXISTS `sms_journey_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_journey_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender_uid` int(11) unsigned DEFAULT NULL COMMENT '发送者 uid',
  `phone` varchar(64) NOT NULL COMMENT '接收的电话号码',
  `topic` varchar(64) NOT NULL COMMENT '这条短信的主题',
  `message` text NOT NULL COMMENT '短信内容',
  `success` tinyint(1) unsigned NOT NULL COMMENT '是否成功 0 表示失败 1 表示成功',
  `created_ts` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sender_uid` (`sender_uid`),
  KEY `phone` (`phone`),
  KEY `topic` (`topic`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `survey_reward_tbl`
--

DROP TABLE IF EXISTS `survey_reward_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_reward_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_survey_id` (`user_id`,`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60234 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `survey_tbl`
--

DROP TABLE IF EXISTS `survey_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trainee_info`
--

DROP TABLE IF EXISTS `trainee_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainee_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `login_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0:未登录,1已登录',
  `nickname` varchar(128) NOT NULL,
  `offer_coin` int(11) unsigned NOT NULL,
  `activity_day` int(11) unsigned NOT NULL,
  `last_activity_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `3rd_biz_token` varchar(128) DEFAULT '',
  `phone` varchar(64) DEFAULT '',
  `memo` varchar(1024) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4098582 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trainee_topn_temp`
--

DROP TABLE IF EXISTS `trainee_topn_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainee_topn_temp` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `master_id` int(11) unsigned NOT NULL,
  `rank_num` int(11) unsigned NOT NULL COMMENT '排名',
  `trainee_num` int(11) unsigned NOT NULL,
  `total_contribution_value` int(11) NOT NULL COMMENT '所有徒弟的贡献值',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `unconfirmed_master_trainee`
--

DROP TABLE IF EXISTS `unconfirmed_master_trainee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unconfirmed_master_trainee` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) NOT NULL,
  `device_id` varchar(128) DEFAULT NULL,
  `source` varchar(64) DEFAULT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '0: 新手任务上线前的司徒关系, 1:新手任务上线后的司徒关系， 99: 假徒弟, 100,',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_done` smallint(6) DEFAULT '0' COMMENT '是否通过did获取到trainee_id,并且更新到master_trainee_v2表中',
  `mac_addr` varchar(128) DEFAULT NULL,
  `device_type` tinyint(4) DEFAULT '0',
  `unique_did` varchar(128) DEFAULT '',
  `flavor` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_id` (`master_id`),
  KEY `ts` (`ts`),
  KEY `is_done` (`is_done`)
) ENGINE=MyISAM AUTO_INCREMENT=811869 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `url_query_to_short_path`
--

DROP TABLE IF EXISTS `url_query_to_short_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_query_to_short_path` (
  `id` bigint(20) unsigned NOT NULL,
  `url_query` varchar(200) NOT NULL,
  `short_path` varchar(30) NOT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_query` (`url_query`),
  UNIQUE KEY `short_link` (`short_path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_addr_tbl`
--

DROP TABLE IF EXISTS `user_addr_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_addr_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `recipients` varchar(128) NOT NULL,
  `addr` varchar(1024) NOT NULL,
  `postcode` varchar(64) NOT NULL,
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `ts` (`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=174114 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_bank_card_tbl`
--

DROP TABLE IF EXISTS `user_bank_card_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_bank_card_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `real_name` varchar(256) DEFAULT '',
  `province` varchar(256) DEFAULT '',
  `bank_branch` varchar(256) DEFAULT '',
  `bank_name` varchar(64) DEFAULT '',
  `card_num` varchar(64) DEFAULT '',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`user_id`,`bank_name`),
  KEY `user_id_and_ts` (`user_id`,`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=10542 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_elec_wallet_tbl`
--

DROP TABLE IF EXISTS `user_elec_wallet_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_elec_wallet_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `elec_wallet_name` varchar(64) DEFAULT '',
  `card_num` varchar(64) DEFAULT '',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`user_id`,`elec_wallet_name`),
  KEY `user_id_and_ts` (`user_id`,`ts`)
) ENGINE=MyISAM AUTO_INCREMENT=3290 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_event_counter_tbl`
--

DROP TABLE IF EXISTS `user_event_counter_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_event_counter_tbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `event_name` varchar(128) NOT NULL COMMENT '事件名称（唯一）',
  `event_count` int(10) unsigned NOT NULL COMMENT '事件次数',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_event` (`user_id`,`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6044706 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_deposit_tbl`
--

DROP TABLE IF EXISTS `user_exchange_deposit_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_deposit_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户 id',
  `req_id` varchar(36) NOT NULL COMMENT '请求流水 id',
  `rsp_id` varchar(36) DEFAULT NULL COMMENT '对方处理流水 id',
  `currency` float NOT NULL COMMENT '钻石金额',
  `coin` float NOT NULL COMMENT '金币',
  `ratio` float NOT NULL COMMENT '汇率',
  `extra_info` varchar(256) DEFAULT NULL COMMENT '充值属性附属字段，目前保存消费金额和剩余金额',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '兑换状态，0:初始, 1:进行中, 2:成功, 3:失败, 4:发送数据异常, 5: 接收数据异常, 6: 消费金币异常',
  `is_consume_gold` smallint(1) DEFAULT '0' COMMENT '是否已经扣钱，0: 没扣钱，1: 已扣钱',
  `is_append_back_gold` smallint(1) DEFAULT '0' COMMENT '兑换失败后是否成功补回钱，0: 否，1: 是',
  `result` varchar(1024) DEFAULT NULL COMMENT '兑换商返回处理结果',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_flow_id` (`req_id`),
  KEY `uid` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_gift_tbl`
--

DROP TABLE IF EXISTS `user_exchange_gift_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_gift_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `activity_name` varchar(128) DEFAULT NULL,
  `gift_enum` smallint(6) DEFAULT NULL COMMENT '"cup": 1;"bottle": 2;"mi_headset": 3;"mi_battery": 4;"Rice cooker": 5;"mi_speaker": 6;"mi_wristband": 7;"mixer": 8;"Induction_cooker": 9;"gas_stove": 10;"Bluetooth audio": 11',
  `number` smallint(6) DEFAULT NULL COMMENT '兑换礼品的张数',
  `coin` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '消费的金币数',
  `gift_desc` varchar(256) DEFAULT NULL,
  `provide_stat` smallint(6) DEFAULT '2' COMMENT '2: 还没有发放给用户，未到账; 1: 已经发放给用户',
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `provide_utc` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_name` (`activity_name`),
  KEY `gift_enum` (`gift_enum`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`)
) ENGINE=MyISAM AUTO_INCREMENT=2339 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_money_by_bank`
--

DROP TABLE IF EXISTS `user_exchange_money_by_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_money_by_bank` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `real_name` varchar(256) DEFAULT '',
  `province` varchar(256) DEFAULT '',
  `bank_branch` varchar(256) DEFAULT '',
  `money` bigint(20) unsigned NOT NULL DEFAULT '0',
  `cost` bigint(20) unsigned NOT NULL DEFAULT '15000',
  `bank_name` varchar(64) DEFAULT '',
  `card_num` varchar(64) DEFAULT '',
  `memo` varchar(1024) DEFAULT NULL COMMENT '备注',
  `provide_stat` smallint(6) DEFAULT '2' COMMENT '2: 还没有发放给用户，未到账; 1: 已经发放给用户; 3:发放失败',
  `update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `provide_utc` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL COMMENT '类型',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `event_id` (`event_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5914 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_money_by_elec_wallet`
--

DROP TABLE IF EXISTS `user_exchange_money_by_elec_wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_money_by_elec_wallet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `money` bigint(20) unsigned NOT NULL DEFAULT '0',
  `cost` bigint(20) unsigned NOT NULL DEFAULT '15000',
  `elec_wallet_name` varchar(64) DEFAULT '',
  `card_num` varchar(64) DEFAULT '',
  `memo` varchar(1024) DEFAULT NULL COMMENT '备注',
  `provide_stat` smallint(6) DEFAULT '2' COMMENT '2: 还没有发放给用户，未到账; 1: 已经发放给用户; 3:发放失败',
  `update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `provide_utc` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=749 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_phone_card`
--

DROP TABLE IF EXISTS `user_exchange_phone_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_phone_card` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `ph_enum` smallint(6) DEFAULT NULL COMMENT '1,2,3三种电话卡',
  `number` smallint(6) DEFAULT NULL COMMENT '兑换电话卡的张数',
  `provide_stat` smallint(6) DEFAULT '2' COMMENT '2: 还没有发放给用户，未到账; 1: 已经发放给用户',
  `update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `provide_utc` int(11) DEFAULT NULL,
  `money` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=30224 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_third_plat_gift_by_diamond_tbl`
--

DROP TABLE IF EXISTS `user_exchange_third_plat_gift_by_diamond_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_third_plat_gift_by_diamond_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open_id` varchar(40) NOT NULL COMMENT '用户 open_id',
  `req_id` varchar(128) NOT NULL COMMENT '请求流水 id',
  `rsp_id` varchar(128) DEFAULT NULL COMMENT '对方处理流水 id',
  `target_owner` varchar(128) NOT NULL COMMENT '兑换商',
  `target_obj_id` varchar(128) NOT NULL COMMENT '兑换目标对象id 例如：游戏id',
  `target_obj_name` varchar(128) DEFAULT NULL COMMENT '兑换目标对象名称 例如：游戏名称',
  `target_id` varchar(128) NOT NULL COMMENT '用户充值主账号',
  `target_sub_id` varchar(128) DEFAULT NULL COMMENT '用户充值子账号',
  `gift_id` varchar(128) NOT NULL COMMENT '礼品 id',
  `gift_desc` varchar(256) DEFAULT NULL COMMENT '礼品描述',
  `number` smallint(6) DEFAULT '0' COMMENT '兑换礼品数量',
  `currency` float NOT NULL COMMENT '充值金额',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '兑换状态，0:初始, 1:进行中, 2:成功, 3:失败, 4:发送数据异常, 5: 接收数据异常, 6: 消费金币异常',
  `is_consume_gold` smallint(1) DEFAULT '0' COMMENT '是否已经扣钱，0: 没扣钱，1: 已扣钱',
  `is_append_back_gold` smallint(1) DEFAULT '0' COMMENT '兑换失败后是否成功补回钱，0: 否，1: 是',
  `return_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `return_result` varchar(1024) DEFAULT NULL COMMENT '兑换商返回处理结果',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_flow_id` (`req_id`),
  KEY `uid` (`open_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exchange_third_plat_gift_tbl`
--

DROP TABLE IF EXISTS `user_exchange_third_plat_gift_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_exchange_third_plat_gift_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户 id',
  `req_id` varchar(128) NOT NULL COMMENT '请求流水 id',
  `rsp_id` varchar(128) DEFAULT NULL COMMENT '对方处理流水 id',
  `target_owner` varchar(128) NOT NULL COMMENT '兑换商',
  `target_obj_id` varchar(128) NOT NULL COMMENT '兑换目标对象id 例如：游戏id',
  `target_obj_name` varchar(128) DEFAULT NULL COMMENT '兑换目标对象名称 例如：游戏名称',
  `target_id` varchar(128) NOT NULL COMMENT '用户充值主账号',
  `target_sub_id` varchar(128) DEFAULT NULL COMMENT '用户充值子账号',
  `gift_id` varchar(128) NOT NULL COMMENT '礼品 id',
  `gift_desc` varchar(256) DEFAULT NULL COMMENT '礼品描述',
  `number` smallint(6) DEFAULT '0' COMMENT '兑换礼品数量',
  `currency` float NOT NULL COMMENT '充值金额',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '兑换状态，0:初始, 1:进行中, 2:成功, 3:失败, 4:发送数据异常, 5: 接收数据异常, 6: 消费金币异常',
  `is_consume_gold` smallint(1) DEFAULT '0' COMMENT '是否已经扣钱，0: 没扣钱，1: 已扣钱',
  `is_append_back_gold` smallint(1) DEFAULT '0' COMMENT '兑换失败后是否成功补回钱，0: 否，1: 是',
  `return_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `return_result` varchar(1024) DEFAULT NULL COMMENT '兑换商返回处理结果',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_flow_id` (`req_id`),
  KEY `uid` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1024462 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_money_journal_error`
--

DROP TABLE IF EXISTS `user_money_journal_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_money_journal_error` (
  `id` bigint(20) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `event_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_id` smallint(6) NOT NULL,
  `direction` varchar(16) NOT NULL DEFAULT 'in' COMMENT '流进流出, = in|out',
  `number` bigint(20) unsigned NOT NULL DEFAULT '0',
  `memo` varchar(1024) DEFAULT NULL COMMENT '备注',
  `sig` varchar(64) NOT NULL,
  `created_at` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_phone_tbl`
--

DROP TABLE IF EXISTS `user_phone_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_phone_tbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `phone` varchar(64) DEFAULT '',
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=MyISAM AUTO_INCREMENT=21298 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_read_cnt_stat`
--

DROP TABLE IF EXISTS `user_read_cnt_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_read_cnt_stat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `read_cnt` int(10) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=20516804 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_score_top_n`
--

DROP TABLE IF EXISTS `user_score_top_n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_score_top_n` (
  `user_id` int(11) NOT NULL,
  `nickname` varchar(128) NOT NULL,
  `rank` int(11) NOT NULL,
  `score` float(15,2) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_treasure_task`
--

DROP TABLE IF EXISTS `user_treasure_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_treasure_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `xb_offer_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned DEFAULT '0' COMMENT '0 未完成 1 已经完成 2 过期',
  `extra_json` varchar(2048) NOT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_2` (`user_id`,`xb_offer_id`),
  KEY `user_id` (`user_id`),
  KEY `created_ts` (`created_ts`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2173587 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_treasure_video_task`
--

DROP TABLE IF EXISTS `user_treasure_video_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_treasure_video_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `video_id` varchar(128) NOT NULL,
  `date_str` varchar(12) NOT NULL,
  `status` tinyint(4) unsigned DEFAULT '0',
  `extra_json` varchar(2048) DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_2` (`user_id`,`video_id`),
  KEY `user_id` (`user_id`),
  KEY `date_str` (`date_str`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=13264211 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `withdraw_deposit`
--

DROP TABLE IF EXISTS `withdraw_deposit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_deposit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `xu_100_limit_cnt` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1800667 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `withdraw_deposit_journal_tbl`
--

DROP TABLE IF EXISTS `withdraw_deposit_journal_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_deposit_journal_tbl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `consume_count` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1074730 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-22 16:50:14
