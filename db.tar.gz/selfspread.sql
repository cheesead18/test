-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: slave.self-spread.mysql.topnews.com    Database: vntopnews_self_spread
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_user_prize`
--

DROP TABLE IF EXISTS `activity_user_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_user_prize` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` tinyint(5) unsigned NOT NULL COMMENT '活动 id',
  `user_id` bigint(20) unsigned NOT NULL,
  `prize_name` varchar(32) NOT NULL COMMENT '奖品名称',
  `prize_content` text COMMENT '奖品内容(JSON)',
  `status` tinyint(4) unsigned DEFAULT '0' COMMENT '奖品状态 0: 未领取 1: 已经领取',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `activity_id_and_user_id` (`user_id`,`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=850 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_mission_daily_type_record`
--

DROP TABLE IF EXISTS `daily_mission_daily_type_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_mission_daily_type_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `mission_id` int(10) unsigned DEFAULT NULL,
  `mission_name` varchar(40) DEFAULT NULL,
  `date_str` varchar(8) DEFAULT NULL,
  `status` tinyint(3) DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`mission_id`,`date_str`)
) ENGINE=MyISAM AUTO_INCREMENT=140910338 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_mission_periodic_type_last_record`
--

DROP TABLE IF EXISTS `daily_mission_periodic_type_last_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_mission_periodic_type_last_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `mission_id` int(10) unsigned DEFAULT NULL,
  `begin_ts` int(10) unsigned DEFAULT NULL,
  `update_ts` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`mission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9642722 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_mission_periodic_type_record`
--

DROP TABLE IF EXISTS `daily_mission_periodic_type_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_mission_periodic_type_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `mission_id` int(10) unsigned NOT NULL,
  `mission_name` varchar(40) NOT NULL,
  `date_str` varchar(8) DEFAULT NULL,
  `begin_ts` int(10) unsigned NOT NULL,
  `end_ts` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) DEFAULT NULL,
  `created_ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`mission_id`,`begin_ts`),
  KEY `date_str` (`date_str`)
) ENGINE=MyISAM AUTO_INCREMENT=36218698 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_sign_in_income`
--

DROP TABLE IF EXISTS `daily_sign_in_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_sign_in_income` (
  `user_id` bigint(20) unsigned NOT NULL,
  `income` double(16,5) DEFAULT NULL,
  `ts` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_record_20190720`
--

DROP TABLE IF EXISTS `daily_task_record_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_record_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `task_name` varchar(30) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6735 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_record_20190721`
--

DROP TABLE IF EXISTS `daily_task_record_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_record_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `task_name` varchar(30) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12647 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_record_20190722`
--

DROP TABLE IF EXISTS `daily_task_record_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_record_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `task_name` varchar(30) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13625 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_task_record_20190723`
--

DROP TABLE IF EXISTS `daily_task_record_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_task_record_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `task_name` varchar(30) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `divination_tbl`
--

DROP TABLE IF EXISTS `divination_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `divination_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL COMMENT '某一年算命信息',
  `sex` varchar(16) NOT NULL COMMENT '算命对象性别',
  `birth_year` int(11) NOT NULL COMMENT '算命对象出生年',
  `info` text COMMENT '算命信息',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `year_sex_birth_year` (`year`,`sex`,`birth_year`)
) ENGINE=InnoDB AUTO_INCREMENT=299 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `divination_user_tbl`
--

DROP TABLE IF EXISTS `divination_user_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `divination_user_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `birth_date` varchar(16) NOT NULL COMMENT '用户出生日期',
  `sex` varchar(16) NOT NULL COMMENT '用户性别',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=187011 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fake_trainee_info`
--

DROP TABLE IF EXISTS `fake_trainee_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fake_trainee_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `master_id` bigint(20) unsigned NOT NULL,
  `trainee_id` bigint(20) unsigned NOT NULL,
  `category` tinyint(4) unsigned DEFAULT '0' COMMENT '假徒弟类别 0: 固定分销页假徒弟',
  `status` tinyint(4) unsigned DEFAULT '0' COMMENT '状态: 0: 正常 1: 不活跃',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trainee_id` (`trainee_id`),
  KEY `master_id` (`master_id`)
) ENGINE=InnoDB AUTO_INCREMENT=382831 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invite_friend_activity_user_info`
--

DROP TABLE IF EXISTS `invite_friend_activity_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite_friend_activity_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `trainee_cnt` int(10) unsigned DEFAULT '0' COMMENT '活动徒弟数',
  `got_prize_cnt` int(10) unsigned DEFAULT '0' COMMENT '已经获得的奖品数量',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=424130 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invite_friend_activity_user_prize`
--

DROP TABLE IF EXISTS `invite_friend_activity_user_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite_friend_activity_user_prize` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `prize_name` varchar(32) NOT NULL COMMENT '奖品名称',
  `prize_content` text COMMENT '奖品内容(JSON)',
  `status` tinyint(4) unsigned DEFAULT '0' COMMENT '奖品状态 0: 未领取 1: 已经领取',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8996 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invite_friend_activity_user_prize_recover_bad`
--

DROP TABLE IF EXISTS `invite_friend_activity_user_prize_recover_bad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite_friend_activity_user_prize_recover_bad` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `prize_name` varchar(32) NOT NULL COMMENT '奖品名称',
  `prize_content` text COMMENT '奖品内容(JSON)',
  `status` tinyint(4) unsigned DEFAULT '0' COMMENT '奖品状态 0: 未领取 1: 已经领取',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lucky_packet_tbl`
--

DROP TABLE IF EXISTS `lucky_packet_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lucky_packet_tbl` (
  `user_id` bigint(20) unsigned NOT NULL,
  `packet_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '活动红包ID',
  `packet_name` varchar(128) NOT NULL COMMENT '活动红包类型：表示不同祝福语的红包',
  `status` int(10) unsigned DEFAULT '0' COMMENT '活动红包状态：0-正常，1-已合成，2-已赠送',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`packet_id`),
  KEY `user_id` (`user_id`),
  KEY `packet_name` (`packet_name`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=MyISAM AUTO_INCREMENT=1505439 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lucky_prize_tbl`
--

DROP TABLE IF EXISTS `lucky_prize_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lucky_prize_tbl` (
  `user_id` bigint(20) unsigned NOT NULL,
  `prize_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '奖品ID，对应配置里面的prize_info',
  `prize_name` varchar(128) NOT NULL COMMENT '奖品类型：金币，奖券，电话卡，手机、耳机等',
  `is_recvd` int(10) unsigned DEFAULT '0' COMMENT '奖品领取状态：0-未领取，1-已领取',
  `recvd_info` varchar(4096) DEFAULT '' COMMENT '奖品扩展信息：电话卡卡密等',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`prize_id`),
  KEY `user_id` (`user_id`),
  KEY `prize_name` (`prize_name`),
  KEY `is_recvd` (`is_recvd`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=MyISAM AUTO_INCREMENT=888799 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `new_user_task_record`
--

DROP TABLE IF EXISTS `new_user_task_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_user_task_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `task_name` varchar(30) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0' COMMENT '0: 未完成 1: 已完成 2: 已经领取奖励',
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=387722 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `new_user_task_user_record`
--

DROP TABLE IF EXISTS `new_user_task_user_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_user_task_user_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `channel` tinyint(3) unsigned DEFAULT '0' COMMENT '0: 默认渠道',
  `completed` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: 未完成 1: 已完成',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=75352 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oppo_invite_trainee_activity_user_info`
--

DROP TABLE IF EXISTS `oppo_invite_trainee_activity_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oppo_invite_trainee_activity_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `trainee_cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '活动收徒数量',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=429589 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oppo_share_activity_user_info`
--

DROP TABLE IF EXISTS `oppo_share_activity_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oppo_share_activity_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `period_offset` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周期偏移量',
  `share_cnt` int(10) unsigned DEFAULT '0' COMMENT '活动分享数',
  `share_visit_cnt` int(10) unsigned DEFAULT '0' COMMENT '分享访问数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`period_offset`)
) ENGINE=InnoDB AUTO_INCREMENT=515322 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=390493 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190717`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=78909 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190718`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=70863 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190719`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=72324 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190720`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=70161 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190721`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=74817 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190722`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=80395 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_open_journal_20190723`
--

DROP TABLE IF EXISTS `spin_game_chest_open_journal_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_open_journal_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned NOT NULL COMMENT '第几次打开',
  `prize_coin` double(16,4) NOT NULL COMMENT '奖励金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_chest_user_info`
--

DROP TABLE IF EXISTS `spin_game_chest_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_chest_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `open_chest_cnt` int(10) unsigned DEFAULT '0' COMMENT '已经打开的箱子数',
  `last_spin_cnt` int(10) unsigned DEFAULT '0' COMMENT '上次打开箱子时的spin_cnt',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=46021 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal`
--

DROP TABLE IF EXISTS `spin_game_draw_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2797612 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190717`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190717`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190717` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=541513 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190718`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190718`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190718` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=481051 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190719`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190719`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190719` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=489685 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190720`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190720`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190720` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=468711 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190721`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190721`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190721` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=501749 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190722`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190722`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190722` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=544379 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_draw_journal_20190723`
--

DROP TABLE IF EXISTS `spin_game_draw_journal_20190723`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_draw_journal_20190723` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `coin_level` double(16,4) unsigned NOT NULL COMMENT '下注金额',
  `prize_ratio` double(16,4) unsigned NOT NULL COMMENT '倍率',
  `prize_coin` double(16,4) unsigned NOT NULL COMMENT '奖金',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1400 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spin_game_user_info`
--

DROP TABLE IF EXISTS `spin_game_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spin_game_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `spin_cnt` int(10) unsigned DEFAULT '0' COMMENT '抽奖次数',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=45982 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ticket_journal_tbl`
--

DROP TABLE IF EXISTS `ticket_journal_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_journal_tbl` (
  `user_id` bigint(20) unsigned NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '抽奖券ID',
  `ticket_memo` varchar(1024) NOT NULL COMMENT '抽奖券信息：例如做什么任务得到的',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=3156807 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ticket_summary_tbl`
--

DROP TABLE IF EXISTS `ticket_summary_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_summary_tbl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `total_tickets` int(10) unsigned DEFAULT '0' COMMENT '累计获得抽奖券数量',
  `remain_tickets` int(10) unsigned DEFAULT '0' COMMENT '剩余可用抽奖券数量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=MyISAM AUTO_INCREMENT=533780 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ticket_task_journal_tbl`
--

DROP TABLE IF EXISTS `ticket_task_journal_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_task_journal_tbl` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `task_id` tinyint(3) unsigned NOT NULL,
  `date_str` varchar(8) NOT NULL,
  `task_name` varchar(20) NOT NULL COMMENT '活动任务名称',
  `status` tinyint(3) unsigned NOT NULL COMMENT '活动任务操作：completed-完成',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`task_id`,`date_str`),
  KEY `created_at` (`created_at`)
) ENGINE=MyISAM AUTO_INCREMENT=2484509 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `time_interval_task_complete_journal`
--

DROP TABLE IF EXISTS `time_interval_task_complete_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_interval_task_complete_journal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_cnt` int(10) unsigned NOT NULL COMMENT '第几次任务',
  `interval_begin_at` int(10) NOT NULL COMMENT '任务开始时间',
  `interval_end_at` int(10) NOT NULL COMMENT '任务结束时间',
  `reward_amount` double(16,5) unsigned NOT NULL COMMENT '奖励数额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=342862 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `time_interval_task_user_info`
--

DROP TABLE IF EXISTS `time_interval_task_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_interval_task_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `task_cnt` int(10) NOT NULL DEFAULT '0' COMMENT '第几次任务',
  `interval_begin_at` int(10) unsigned NOT NULL COMMENT '时段开始时间',
  `reward_amount` double(16,5) unsigned NOT NULL COMMENT '奖励数额',
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=77089 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-22 17:04:31
